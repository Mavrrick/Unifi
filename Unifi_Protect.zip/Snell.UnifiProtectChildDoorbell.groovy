/*
* UnifiProtectChild-Doorbell
*
* Description:
* This Hubitat driver provides a spot to put data from Unifi Protect Doorbell-related devices. It does not belong on it's own and requires
* the UnifiProtectAPI driver as a parent device.
*
* Instructions for using Tile method:
* 1) In "Preferences -> Tile Template" enter your template (example below) and click "Save Preferences"
*   Ex: "[b]Temperature:[/b] @temperature@°@location.getTemperatureScale()@[/br]"
* 2) In a Hubitat dashboard, add a new tile, and select the child/sensor, in the center select "Attribute", and on the right select the "Tile" attribute
* 3) Select the Add Tile button and the tile should appear
* NOTE1: Put a @ before and after variable names
* NOTE2: Should accept most HTML formatting commands with [] instead of <>
* 
* Features List:
* Ability to control general device settings
* Ability to trigger device's locate function
* Ability to check a website (mine) to notify user if there is a newer version of the driver available
* 
* Licensing:
* Copyright 2026 David Snell
* Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
* in compliance with the License. You may obtain a copy of the License at: http://www.apache.org/licenses/LICENSE-2.0
* Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
* on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
* for the specific language governing permissions and limitations under the License.
*
* Version Control:
* 0.2.0 - Replaced all attributes with spaces
* 0.1.25 - Added isStateChange to ProcessEvents
* 0.1.24 - Change to doorbell notification delay as it was milliseconds, not seconds
* 0.1.23 - Change to doorbell notification null value, change to notification methods
* 0.1.22 - Additional change to version method and added image setting when preferences are saved
* 0.1.21 - Corrected version and moved to new version method
* 0.1.20 - Add ability to control recording and streaming statuses
* 0.1.19 - Update to Event logging
* 0.1.18 - Rework of ProcessEvent
* 0.1.17 - Added sound sensor capability
* 0.1.16 - Added ability to send a notification to the Doorbell
* 0.1.15 - Added RefreshRate and imageURL to assist with Easy Dashboard, as well as ImageAsOf and updated event/state handling
* 0.1.14 - Update to the Tile method and attributes for WebHook processing
* 0.1.13 - Inclusion of an attribute to store the userId associated with a fingerprint
* 0.1.12 - Changing refresh to try Camera status because Doorbell no longer works.
* 0.1.11 - Correction of isStateChange
* 0.1.10 - Change to remove old driver-specific variables and events
* 0.1.9 - Correct to button handling and removed space from Button Presses attribute name
* 0.1.8 - Added ReleaseableButton capability and changed driver-specific attribute names to remove spaces
* 0.1.7 - Update to refresh command method
* 0.1.6 - More button-related functionality, updated ProcessEvent, added info logging for push command
* 0.1.5 - Added attribute for Last Motion
* 0.1.4 - Added attribute for smartDetectType
* 0.1.3 - Command to get a snapshot image from the camera
* 0.1.2 - Removed capabilities not applicable to doorbells and added preferences for settings
* 0.1.1 - Added pushable button capability and additional attributes
* 0.1.0 - Initial version
* 
* Thank you(s):
* Thank you to @Cobra for inspiration of how I perform driver version checking
* Thank you to @mircolino for working out a parent/child method and pointing out other areas for significant improvement as well as coming up with the
*   original (no longer used) Tile/HTML Template method
*/

import groovy.transform.Field

#include Mavrrick.Unifi_Protect_Child

@Field static final String DRIVER = "UnifiProtectChild-Doorbell"
// Returns the driver name
def DriverName(){
    return "UnifiProtectChild-Doorbell"
}

@Field static final String VERSION = "0.2.0"
// Returns the driver version
public static String version(){
    return "0.2.0"
}

// Driver Metadata
metadata{
	definition( name: "UnifiProtectChild-Doorbell", namespace: "Snell", author: "David Snell", importUrl: "https://www.drdsnell.com/projects/hubitat/drivers/UnifiProtectChild-Doorbell.groovy" ) {
        capability "Sensor"
        capability "Actuator"
        capability "MotionSensor"
        capability "ImageCapture"
        capability "ImageUrl"
        capability "PushableButton"
        capability "ReleasableButton"
        capability "Refresh"
        capability "Notification"
        capability "SoundSensor"
        
        // Commands
        //command "DoSomething" // For testing and development purposes only, it should not be uncommented for normal use
        command "push"
        command "release"
        command "SetMessageWithDuration", [ [ name: "Message*", type: "STRING", required: true, description: "REQUIRED: The custom message to use." ], [ name: "Duration*", type: "ENUM", required: true, constraints: [ "5 minutes", "30 minutes", "1 hour", "6 hours", "12 hours", "Always" ], defaultValue: "Always", description: "REQUIRED: Set the duration of the custom message." ] ]
        command "ClearNotification"
        command "SetRecordingStatus", [ [ name: "Value*", type: "ENUM", constraints: [ "Always", "Never" ], defaultValue: "Always", description: "REQUIRED: Always have camera record or never record." ] ]
        command "SetStreamingStatus", [ [ name: "Stream*", type: "ENUM", , constraints: [ "High", "Medium", "Low" ], description: "REQUIRED: Which video stream to set." ], [ name: "Value*", type: "ENUM", constraints: [ "Enabled", "Disabled" ], defaultValue: "Enabled", description: "REQUIRED: Whether the selected stream will be enabled or disabled." ] ]

        //command "Locate" // Meant to help identify/locate the particular device by flashing the light
        
        // Attributes for the driver itself
		attribute "DriverName", "string" // Identifies the driver being used for update purposes
		attribute "DriverVersion", "string" // Handles version for driver
        attribute "DriverStatus", "string" // Handles version notices for driver
        
        // General Device Attributes
        attribute "Type", "string" // The type of device, per Ubiquiti data
        
        // Attributes - Device Related
        attribute "Status", "string" // Show success/failure of commands performed
        attribute "DeviceStatus", "string" // Show the current state of the device as reported by the controller

        // Device Attributes
        attribute "Dark", "enum", [ "true", "false" ] // Whether the light level is dark
        attribute "IndicatorEnabled", "enum", [ "true", "false" ] // Whether the camera's indicator is enabled
        attribute "RecordingNow", "enum", [ "true", "false" ] // Whether the camera is recording this moment
        attribute "MotionEventsToday", "number" // Number of motion events today
        attribute "ButtonPresses", "number" // ButtonPresses is used to show the number of button presses
        attribute "SnapshotURL", "string"
        attribute "SnapshotImage", "string"
        attribute "smartDetectType", "string"
        attribute "LastMotion", "string"
        attribute "FingerprintUserID", "string" // Stores the userID received when a fingerprint is read
        attribute "ImageAsOf", "string"
        attribute "Notification", "string"
        attribute "Stream_High", "enum", [ "Enabled", "Disabled" ]  // Whether the High stream is enabled or disabled
        attribute "Stream_Medium", "enum", [ "Enabled", "Disabled" ]  // Whether the Medium stream is enabled or disabled
        attribute "Stream_Low", "enum", [ "Enabled", "Disabled" ]  // Whether the Low stream is enabled or disabled
        attribute "RecordingMode", "enum", [ "Always", "Never", "Schedule" ]  // What recording mode is being used
        attribute "Alarms", "string"
        attribute "Thumbnail", "string"
        
        // WebHook AI related Attributes
        attribute "AIRecognitionType", "string" // Stores the Type of AI detection triggered
        attribute "AIRecognitionValue", "string" // Stores the ID associated with a persons face as recognized by AI
        
        // Attributes to help with Easy Dashboards
        attribute "refreshRate", "string" // 
        
        // Tile Template attribute
        attribute "Tile", "string"; // Ex: "[b]Temperature:[/b] @temperature@°@location.getTemperatureScale()@[/br]"
        
    }
	preferences{
        if( ShowAllPreferences ){
            input( type: "enum", name: "RefreshRate", title: "<b>Image Refresh Rate</b>", required: true, multiple: false, options: [ "Manual", "30 seconds", "1 minute", "5 minutes", "10 minutes", "15 minutes", "30 minutes", "1 hour", "3 hours" ], defaultValue: "Manual" )
            input( type: "number", name: "MicVolume", title: "<b>Microphone Volume</b>", description: "<font size='2'>0 to 100</font>", required: true, defaultValue: 100, range: "0..100" )
            input( type: "bool", name: "StatusLED", title: "<b>Status LED On/Off</b>", defaultValue: false)
            input( type: "bool", name: "ExternalIR", title: "<b>External IR Lights On/Off</b>", defaultValue: false)
            input( type: "bool", name: "SystemSounds", title: "<b>System Status Sounds On/Off</b>", defaultValue: false)
            input( type: "int", name: "MaxPresses", title: "<b>Max button presses before rolling over</b>", required: false, defaultValue: 4 )
            input( type: "string", name: "DeviceName", title: "<b>Device Name</b>", description: "<font size='2'>If set it will change the device's name on the controller.</font>", defaultValue: "${ device.label }")
            input( name: "TileTemplate", type: "string", title: "<b>Tile Template</b>", description: "<font size='2'>Ex: [b]Temperature:[/b] @temperature@&deg;@location.getTemperatureScale()@[/br]</font>", defaultValue: "");
            input( type: "enum", name: "LogType", title: "<b>Enable Logging?</b>", required: false, multiple: false, options: [ "None", "Info", "Debug", "Trace" ], defaultValue: "Info" )
            input( type: "bool", name: "ShowAllPreferences", title: "<b>Show All Preferences?</b>", defaultValue: true )
        } else {
            input( type: "bool", name: "ShowAllPreferences", title: "<b>Show All Preferences?</b>", defaultValue: true )
        }
	}
}


// DoSomething is for testing and development purposes. It should not be uncommented for normal usage.
def DoSomething(){

}

// updated
def updated( boolean NewDevice = false ){
    if( LogType == null ){
        LogType = "Info"
    }
    
    if( NewDevice != true ){
        SendSettings()
    }
    
    // Set basic button info
    if( MaxPresses == null ){
        MaxPresses = 4
    }
    ProcessState( "MaxPresses", MaxPresses )
    
    ProcessEvent( "numberOfButtons", 1 )
    ProcessEvent( "ButtonPresses", 0 )
    
    ProcessEvent( "DriverName", DRIVER, null )
    ProcessEvent( "DriverVersion", VERSION, null )
    ProcessEvent( "DriverStatus", null, null )
    
    // Schedule daily check for driver updates to notify user
    def Hour = ( new Date().format( "h" ) as int )
    def Minute = ( new Date().format( "m" ) as int )
    def Second = ( new Date().format( "s" ) as int )
    
    unschedule()
    // Check what the refresh rate is set for then run it
    switch( RefreshRate ){
        case "30 seconds": // Schedule the camera to take a new image every 30 seconds
            schedule( "0/30 * * ? * *", "take" )
            break
        case "1 minute": // Schedule the camera to take a new image every minute
            schedule( "${ Second } * * ? * *", "take" )
            break
        case "5 minutes": // Schedule the camera to take a new image every 5 minutes
            schedule( "${ Second } 0/5 * ? * *", "take" )
            break
        case "10 minutes": // Schedule the camera to take a new image every 10 minutes
            schedule( "${ Second } 0/10 * ? * *", "take" )
            break
        case "15 minutes": // Schedule the camera to take a new image every 15 minutes
            schedule( "${ Second } 0/15 * ? * *", "take" )
            break
        case "30 minutes": // Schedule the camera to take a new image every 30 minutes
            schedule( "${ Second } 0/30 * ? * *", "take" )
            break
        case "1 hour": // Schedule the camera to take a new image every hour
            schedule( "${ Second } ${ Minute } * ? * *", "take" )
            break
        case "3 hours": // Schedule the camera to take a new image every 3 hours
            schedule( "${ Second } ${ Minute } 0/3 ? * *", "take" )
            break
        default:
            RefreshRate = "Manual"
            break
    }
    Logging( "Camera refresh rate: ${ RefreshRate }", 4 )
    ProcessEvent( "refreshRate", RefreshRate, null )
    
    // Schedule checks that are only performed once a day
    schedule( "${ Second } ${ Minute } ${ Hour } ? * *", "CheckForUpdate" )
    
    // If the device id is known, set default values for image, imageUrl, and Thumbnail since they will never actually change
    if( state.ID != null ){
        ProcessEvent( "image", "http://${ location.hub.localIP }/local/${ state.ID }_Image.jpg", null )
        ProcessEvent( "imageUrl", "http://${ location.hub.localIP }/local/${ state.ID }_Image.jpg", null )
        ProcessEvent( "Thumbnail", "<img width=\"20%\" height=\"20%\" src=\"http://${ location.hub.localIP }/local/Camera_${ state.ID }_Image.jpg\">" )
    }
    
    Logging( "Updated", 2 )
}

// Support the ability to send notifications to the doorbell
def deviceNotification( text ){
    //parent.DoorbellNotification( device.getDeviceNetworkId(), state.ID, "{\"lcdMessage:\"[\"type\":\"CUSTOM_MESSAGE\",\"text\":\"${ text }\",\"resetAt\":\"null\"]}" )
    parent.DoorbellNotification( device.getDeviceNetworkId(), state.ID, "{\"lcdMessage\":{\"type\":\"CUSTOM_MESSAGE\",\"text\":\"${ text }\",\"resetAt\":null}}" )
}
                                                 
// Support the ability to send notifications with duration to the doorbell
def SetMessageWithDuration( String Message, String Duration ){
    def Delay = null
    switch( Duration ){
        case "5 minutes": // Schedule message to be reset in 5 minutes
            Delay = 300000
            break
        case "30 minutes": // Schedule message to be reset in 30 minutes
            Delay = 1800000
            break
        case "1 hour": // Schedule message to be reset in 1 hour
            Delay = 3600000
            break
        case "6 hours": // Schedule message to be reset in 1 hour
            Delay = 21600000
            break
        case "12 hours": // Schedule message to be reset in 1 hour
            Delay = 43200000
            break
        default:
            Delay = null
            break
    }
    if( Delay != null ){
        Delay = ( ( new Date().time ) + ( Delay as long ) )
    }
    parent.DoorbellNotification( device.getDeviceNetworkId(), state.ID, "{\"lcdMessage\":{\"type\":\"CUSTOM_MESSAGE\",\"text\":\"${ Message }\",\"resetAt\":${ Delay }}}" )
}

// Support the ability to clear the notification on the doorbell
def ClearNotification(){
    parent.DoorbellNotification( device.getDeviceNetworkId(), state.ID, "{\"lcdMessage\":{\"resetAt\":0}}" )
}

// Set Recording Status
def SetRecordingStatus( Value ){
    if( state.ID != null ){
        parent.SetRecordingStatus( device.getDeviceNetworkId(), state.ID, Value )
    } else {
        Logging( "No ID for ${ device.getDeviceNetworkId() }, cannot set recording status", 5 )
    }
}

// Set Streaming Status
def SetStreamingStatus( Stream, Value ){
    if( state.ID != null ){
        if( state.Channels != null ){
            def StreamNum
            if( Stream == "High" ){
                StreamNum = 0
            } else if( Stream == "Medium" ){
                StreamNum = 1
            } else {
                StreamNum = 2
            }
            if( ( ( Value == "Enabled" ) && ( state.Channels[ StreamNum ].isRtspEnabled == true ) ) || ( ( Value == "Disabled" ) && ( state.Channels[ StreamNum ].isRtspEnabled == false ) ) ){
                Logging( "${ Stream } stream already set for ${ Value }", 2 )
            } else {
        		parent.SetStreamingStatus( device.getDeviceNetworkId(), state.ID, Stream, Value, state.Channels )
            }
        } else {
            Logging( "Channel data blank, cannot set streaming status. Try refreshing device first.", 5 )
        }
    } else {
        Logging( "No ID. Cannot set streaming status", 5 )
    }
}

// Handle any button push activities
def push( Number Button = 1 ){
    ProcessEvent( "pushed", 1, null )
//    state.pushed = 1
    //ProcessEvent( "pushed", Button, null )
    def Presses
    if( state.ButtonPresses != null ){
        Presses = ( state.ButtonPresses + 1 ) as int
    } else {
        Presses = 1
    }
    def Max
    if( MaxPresses != null ){
        Max = ( MaxPresses as int )
    } else {
        Max = 4
    }
    if( Presses > Max ){
        Presses = 1
    }
    ProcessEvent( "ButtonPresses", Presses, null ) 
    Logging( "Button ${ Button } pressed & number of presses = ${ Presses }", 2 )
}

// Handle any button release activities
def release( Number Button = 1 ){
    ProcessEvent( "released", Button, null )
    Logging( "Button ${ Button } released", 2 )
}

// Attempts to trigger a snapshot image from the doorbell
def take(){
    if( state.ID != null ){
        Logging( "Attempting to take a snapshot image", 2 )
        parent.GetSnapshot( state.ID, device.getDeviceNetworkId() )
    } else {
        Logging( "No ID for ${ device.getDeviceNetworkId() }, cannot get snapshot", 5 )
    } 
}

// refresh information on the specific child
def refresh(){
    if( state.ID != null ){
        parent.GetCameraStatus( device.getDeviceNetworkId(), state.ID )
    } else {
        Logging( "No ID for ${ device.getDeviceNetworkId() }, cannot refresh", 5 )
    }
}

// Turn on the device's locate function to help locate/identify it
def Locate(){
    if( state.ID != null ){
        parent.LocateDoorbell( device.getDeviceNetworkId(), state.ID )
    } else {
        Logging( "No ID for ${ device.getDeviceNetworkId() }, cannot activate identify function", 5 )
    }
}

// Configure device settings based on Preferences
def SendSettings(){
    if( state.ID != null ){
        if( DeviceName != null && DeviceName != device.label ){
            parent.SendCameraSettings( device.getDeviceNetworkId(), state.ID, "{\"micVolume\":${ MicVolume },\"name\":\"${ DeviceName }\",\"ledSettings\":{\"isEnabled\":${ StatusLED }},\"ispSettings\":{\"isExternalIrEnabled\":${ ExternalIR }},\"speakerSettings\":{\"areSystemSoundsEnabled\":${ SystemSounds }}}" )
        } else {
            parent.SendCameraSettings( device.getDeviceNetworkId(), state.ID, "{\"micVolume\":${ MicVolume },\"name\":\"${ device.label }\",\"ledSettings\":{\"isEnabled\":${ StatusLED }},\"ispSettings\":{\"isExternalIrEnabled\":${ ExternalIR }},\"speakerSettings\":{\"areSystemSoundsEnabled\":${ SystemSounds }}}" )
        }
    } else {
        Logging( "No ID for ${ device.getDeviceNetworkId() }, cannot send settings", 5 )
    }
}

// installed is called when the device is installed, all it really does is run updated
def installed(){
	Logging( "Installed", 2 )
	updated( true )
}

// initialize is called when the device is initialized, all it really does is run updated
def initialize(){
	Logging( "Initialized", 2 )
	updated( true )
}

/*
// Return a state value
def ReturnState( Variable ){
    return state."${ Variable }"
}

// Tile method to produce HTML formatted string for dashboard use
private void UpdateTile( String val ){
    if( TileTemplate != null ){
        def TempString = ""
        Parsing = TileTemplate
        Parsing = Parsing.replaceAll( "\\[", "<" )
        Parsing = Parsing.replaceAll( "\\]", ">" )
        Count = Parsing.count( "@" )
        if( Count >= 1 ){
            def x = 1
            while( x <= Count ){
                TempName = Parsing.split( "@" )[ x ]
                switch( TempName ){
                    case "location.latitude":
                        Value = location.latitude
                        break
                    case "location.longitude":
                        Value = location.longitude
                        break
                    case "location.getTemperatureScale()":
                        Value = location.getTemperatureScale()
                        break
                    default:
                        Value = ReturnState( "${ TempName }" )
                        break
                }
                TempString = TempString + Parsing.split( "@" )[ ( x - 1 ) ] + Value
                x = ( x + 2 )
            }
            if( Parsing.split( "@" ).last() != Parsing.split( "@" )[ Count - 1 ] ){
                TempString = TempString + Parsing.split( "@" ).last()
            }
        } else if( Count == 1 ){
            TempName = Parsing.split( "@" )[ 1 ]
            switch( TempName ){
                case "location.latitude":
                    Value = location.latitude
                    break
                case "location.longitude":
                    Value = location.longitude
                    break
                case "location.getTemperatureScale()":
                    Value = location.getTemperatureScale()
                    break
                default:
                    Value = ReturnState( "${ TempName }" )
                    break
            }
            TempString = TempString + Parsing.split( "@" )[ 0 ] + Value
        } else {
            TempString = TileTemplate    
        }
        Logging( "Tile = ${ TempString }", 4 )
        sendEvent( name: "Tile", value: TempString )
    }
}

// Send event for device
def ProcessEvent( Variable, Value, Unit = null, Description = null ){
    sendEvent( name: Variable, value: Value, unit: Unit, descriptionText: Description, isStateChange: true )
    if( Unit != null ){
        if( Description != null ){
            Logging( "Event: ${ Variable } = ${ Value } Unit = ${ Unit } Description = ${ Description }", 4 )
        } else {
            Logging( "Event: ${ Variable } = ${ Value } Unit = ${ Unit }", 4 )
        }
    } else {
        if( Description != null ){
            Logging( "Event: ${ Variable } = ${ Value } Description = ${ Description }", 4 )
        } else {
            Logging( "Event: ${ Variable } = ${ Value }", 4 )
        }
    }
//    ProcessState( Variable, Value )
}

// Set a state variable to a value
def ProcessState( Variable, Value ){
    Logging( "State: ${ Variable } = ${ Value }", 4 )
    state."${ Variable }" = Value
    UpdateTile( "${ Value }" )
}

// Handles whether logging is enabled and thus what to put there.
def Logging( LogMessage, LogLevel ){
	// Add all messages as info logging
    if( ( LogLevel == 2 ) && ( LogType != "None" ) ){
        log.info( "${ device.displayName } - ${ LogMessage }" )
    } else if( ( LogLevel == 3 ) && ( ( LogType == "Debug" ) || ( LogType == "Trace" ) ) ){
        log.debug( "${ device.displayName } - ${ LogMessage }" )
    } else if( ( LogLevel == 4 ) && ( LogType == "Trace" ) ){
        log.trace( "${ device.displayName } - ${ LogMessage }" )
    } else if( LogLevel == 5 ){
        log.error( "${ device.displayName } - ${ LogMessage }" )
    }
}

// Checks drdsnell.com for the latest version of the driver
// Original inspiration from @cobra's version checking
def CheckForUpdate(){
    ProcessEvent( "DriverName", DRIVER )
    ProcessEvent( "DriverVersion", VERSION )
	httpGet( uri: "https://www.drdsnell.com/projects/hubitat/drivers/versions.json", contentType: "application/json" ){ resp ->
        switch( resp.status ){
            case 200:
                if( resp.data."${ DRIVER }" ){
                    CurrentVersion = VERSION.split( /\./ )
                    if( resp.data."${ DRIVER }".version == "REPLACED" ){
                       ProcessEvent( "DriverStatus", "Driver replaced, please use ${ resp.data."${ DRIVER }".file }" )
                    } else if( resp.data."${ DRIVER }".version == "REMOVED" ){
                       ProcessEvent( "DriverStatus", "Driver removed and no longer supported." )
                    } else {
                        SiteVersion = resp.data."${ DRIVER }".version.split( /\./ )
                        if( CurrentVersion == SiteVersion ){
                            Logging( "Driver version up to date", 2 )
				            ProcessEvent( "DriverStatus", "Up to date" )
                        } else if( ( CurrentVersion[ 0 ] as int ) > ( SiteVersion [ 0 ] as int ) ){
                            Logging( "Major development ${ CurrentVersion[ 0 ] }.${ CurrentVersion[ 1 ] }.${ CurrentVersion[ 2 ] } version", 4 )
				            ProcessEvent( "DriverStatus", "Major development ${ CurrentVersion[ 0 ] }.${ CurrentVersion[ 1 ] }.${ CurrentVersion[ 2 ] } version" )
                        } else if( ( CurrentVersion[ 1 ] as int ) > ( SiteVersion [ 1 ] as int ) ){
                            Logging( "Minor development ${ CurrentVersion[ 0 ] }.${ CurrentVersion[ 1 ] }.${ CurrentVersion[ 2 ] } version", 4 )
				            ProcessEvent( "DriverStatus", "Minor development ${ CurrentVersion[ 0 ] }.${ CurrentVersion[ 1 ] }.${ CurrentVersion[ 2 ] } version" )
                        } else if( ( CurrentVersion[ 2 ] as int ) > ( SiteVersion [ 2 ] as int ) ){
                            Logging( "Patch development ${ CurrentVersion[ 0 ] }.${ CurrentVersion[ 1 ] }.${ CurrentVersion[ 2 ] } version", 4 )
				            ProcessEvent( "DriverStatus", "Patch development ${ CurrentVersion[ 0 ] }.${ CurrentVersion[ 1 ] }.${ CurrentVersion[ 2 ] } version" )
                        } else if( ( SiteVersion[ 0 ] as int ) > ( CurrentVersion[ 0 ] as int ) ){
                            Logging( "New major release ${ SiteVersion[ 0 ] }.${ SiteVersion[ 1 ] }.${ SiteVersion[ 2 ] } available", 2 )
				            ProcessEvent( "DriverStatus", "New major release ${ SiteVersion[ 0 ] }.${ SiteVersion[ 1 ] }.${ SiteVersion[ 2 ] } available" )
                        } else if( ( SiteVersion[ 1 ] as int ) > ( CurrentVersion[ 1 ] as int ) ){
                            Logging( "New minor release ${ SiteVersion[ 0 ] }.${ SiteVersion[ 1 ] }.${ SiteVersion[ 2 ] } available", 2 )
				            ProcessEvent( "DriverStatus", "New minor release ${ SiteVersion[ 0 ] }.${ SiteVersion[ 1 ] }.${ SiteVersion[ 2 ] } available" )
                        } else if( ( SiteVersion[ 2 ] as int ) > ( CurrentVersion[ 2 ] as int ) ){
                            Logging( "New patch ${ SiteVersion[ 0 ] }.${ SiteVersion[ 1 ] }.${ SiteVersion[ 2 ] } available", 2 )
				            ProcessEvent( "DriverStatus", "New patch ${ SiteVersion[ 0 ] }.${ SiteVersion[ 1 ] }.${ SiteVersion[ 2 ] } available" )
                        }
                    }
                } else {
                    Logging( "${ DRIVER } is not published on drdsnell.com", 2 )
                    ProcessEvent( "DriverStatus", "${ DRIVER } is not published on drdsnell.com" )
                }
                break
            default:
                Logging( "Unable to check drdsnell.com for ${ DRIVER } driver updates.", 2 )
                break
        }
    }
}

*/