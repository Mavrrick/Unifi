/*
* UnifiProtectAPI
*
* Description:
* This Hubitat driver allows polling of the Unifi Protect API as well as some control of child devices such as cameras, sensors, and lights.
*
* Overall Setup:
* 1) Add both the UnifiProtectAPI.groovy and the related child drivers as new user drivers
* 2) Add a Virtual Device for the parent
* 3) Enter the Unifi's IP/Hostname, Username, Password, and select the Controller Type in the Preference fields and Save Preferences
* REQUIRED that the Unifi user has local access to the controller and is not using MFA. If needed, create a new admin user locally on the
*   controller and select the "Restrict to local access only" checkbox.
* REQUIRED for "Other Unifi Controllers" Controller Type: Set the Controller Port #. This Preference will appear after you Save Preferences.
*   Set it, then Save Preferences again. This defaults to 7443 but newer version software may be using 443.
* OPTIONAL: Refresh Rate, Logging, and whether WebSockets are enabled (WebSockets are used for immediate notifications from cameras and sensors)
*
* Features List:
* WebSocket notifications allow immediate notification of motion and other events
* Shows NVR CPU and memory/storage usage as well as uptime and general status
* Shows Bridge uptime and general status
* Shows Light data and status such as whether it is on or current has motion, although this is impacted by the refresh rate
* Allow basic control of a Light-based device
* Allow basic control of cameras and doorbells
* Allow basic control and movement of PTZ cameras
* Checks drdsnell.com for an updated driver on a daily basis
*
* Licensing:
* Copyright 2026 David Snell
* Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
* in compliance with the License. You may obtain a copy of the License at: http://www.apache.org/licenses/LICENSE-2.0
* Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
* on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
* for the specific language governing permissions and limitations under the License.
*
* Known Issue(s):
* 
* Version Control:
* 0.2.79 - Significant changes to websocket handling, additional categories of WebSocket content, & additional data handling
* 0.2.78 - Correction for when a Sensor device is null
* 0.2.77 - Improvements to WebSocket handling stability and device data plus some changes to whether data gets sent to sensor children that they cannot use
* 0.2.76 - Removed motionDetectedAt workaround, excluded non-sensors from GetSensorStatus, renamed Auth Key to AuthKey, changes to some command logging,
*  & additional data handling
* 0.2.75 - Added additional ChildID checks for when motion is detected
* 0.2.74 - Added additional sensor checks when motion is detected to determine if inactive, extra checking for ChildIDs, and additional data handling
* 0.2.73 - Added a few additional null data checks and a bit of data handling
* 0.2.72 - Additional data handling
* 0.2.71 - Further corrections to try to improve doorbell button
* 0.2.70 - Should have removed second doorbell push from websocket data
* 0.2.69 - Changes to how doorbell button is "pushed"
* 0.2.68 - Added Reboot system capability to parent device
* 0.2.67 - Adjustments to try to better identify motion from a SuperLink motion sensor, cleaned out extraneous nulls, additional data handling, some code cleanup
* 0.2.66 - Commented out "DoSomething" test command, added PTZ identification for 3rd party cameras, additional data handling
* 0.2.65 - Adjustments to how PTZ movement is handled and driver version checking
* 0.2.64 - Additional data handling & fix for WebSocketFailures variable error
* 0.2.63 - Change to Login array handling and additional data handling
* 0.2.62 - Fix to isRtspEnabled (stream not existing), and additional data handling
* 0.2.61 - Added basic control of camera recording and streaming
* 0.2.60 - Added helper code for @mavrrick58's Integration app.
* 0.2.59 - Adjustments to WebSocket failure notification and logging as well as removal of forced events for parent and children
* 0.2.58 - Added sound sensor recognition, some code simplification/cleanup, and additional data handling
* 0.2.57 - Additional data handling
* 0.2.56 - Simplified device categorization and additional data handling
* 0.2.55 - Added additional handling
* 0.2.54 - Added doorbell notification messaging and handled additional data
* 0.2.53 - Additional data handling and corrected typo in PostEventToChild
* 0.2.52 - Changes to how Events and States are handled and sent to child devices, addition of ImageAsOf event
* 0.2.51 - Additional code to allow WebHook processing from @mavrrick58
* 0.2.50 - Typo correction for smartDetectTypes
* 0.2.49 - Change to smartDetectTypes data handling, additional data handling, and a new WebSocket type
* 0.2.48 - Change to Fingerprint data point due to Ubiquiti change
* 0.2.47 - Additional data handling
* 0.2.46 - Changed fingerprint data to be a forced event, so it will always be published
* 0.2.45 - Put fingerprint data to null if no userId provided
* 0.2.44 - Initial inclusion of fingerprint data for Doorbell
* 0.2.43 - Slight changes to WebSocket code for readability
* 0.2.42 - Rework of WebSocket code per @tomw's newer basis
* 0.2.41 - Adding support for 3rd-party camera attributes
* 0.2.40 - Handling for more data returned from the API, correction for turning off WebSockets, and correction to CPU Load %
* 0.2.39 - Added ability for PTZ cameras to go to preset positions, change to StopMoving command, and some additional data handling
* 0.2.38 - Switch PTZ cameras to new PTZCamera child driver, initial support for Pan/Tilt/Zoom/Home/Stop functions with a G5 PTZ as testbed
* 0.2.37 - Handling for changed authorization Token name in newer versions of Unifi OS
* 0.2.36 - Correction of isStateChange
* 0.2.35 - Additional handling for webSocket types
* 0.2.34 - Change to remove old driver-specific variables and events plus some data handling
* 0.2.33 - Added PowerDown command
* 0.2.32 - Added webSocket handling to try to deal with doorbell "ring" type and changed driver-specific attribute names to remove spaces
* 0.2.31 - Added device recognition for UVC G4 Doorbell Pro PoE
* 0.2.30 - Handling for additional data points returned by the API
* 0.2.29 - Change to receiving CSRF to account for changes in Unifi OS 3.2.8 and additional data handling
* 0.2.28 - Changes to parse to handle smart events better, using code from @blocklanders
* 0.2.27 - Additional null data handling in WebSocket code
* 0.2.26 - Additional handling for contact and motion from Sensors
* 0.2.25 - Added Sensor settings to accomodate API changes
* 0.2.24 - Handling for null epoch values
* 0.2.23 - Added recognition of additional data, particularly around sensors
* 0.2.22 - Adds ability to force child events to be isChanged
* 0.2.21 - Including CSRF in Login even if null
* 0.2.20 - Changes to accomodate UP-Sense sensor
* 0.2.19 - Correction to smartDetect indices per @dcaton1220 and attempt at handling multiple types
* 0.2.18 - Changes to Login error handling (trying to handle MFA better) and change to Uptime data handling for when devices add 000
* 0.2.17 - Revisions to WebSocket handling including input from @dcaton1220
* 0.2.16 - Removed calls for Login and refresh from within the WebSocket activities
* 0.2.15 - Reduced events triggered by WebSocket status activity, overhaul of WebSocket returned events handling, and correction to parent GetSnapshot command
* 0.2.14 - Adding smartDetectType into WebSocket data handling also changed how WebSocket Failures and LoginRetries are handled/tracked
* 0.2.13 - Added some Trace logging to the WebSocket data portion
* 0.2.12 - Changes to WebSocket code to try to more closely match @tomw's
* 0.2.11 - Cookie expiration may have changed so Login now happens every 10 minutes to account for it and now ignoring liveviews data (not useful at this time)
* 0.2.10 - Added Controller Port # preference for Other Unifi Controllers, removed PollingOK, site attribute, and excessive WebSocket logging,
*  added GetMotionEvents command however it just dumps data to Trace logging at this time
* 0.2.9 - Handle null uptime data
* 0.2.8 - Ability to get a snapshot image from a camera and better logging for adding child driver error
* 0.2.7 - Corrections to WebSocket handling (due to Ubiquiti changes) as well as additional data points handled
* 0.2.6 - Additional data points handled
* 0.2.5 - Added ability to save settings for camera devices
* 0.2.4 - Addition of initial websocket monitoring
* 0.2.3 - Changes to the driver version checking, moved child device data processing to parent, and added support for Doorbell child
* 0.2.2 - Initial addition of support for Camera devices
* 0.2.1 - Additional commands for light devices
* 0.2.0 - Setting up for different child devices with different drivers and attempting to have relevant child commands
* 0.1.3 - Correction to driver update checking code
* 0.1.2 - Added read-only support for recognize lights
* 0.1.1 - Some cleanup from Network leftovers
* 0.1.0 - Initial version
* 
* Thank you(s):
* @mavrrick58 for WebHook processing idea and code, as well as Integration app
* @tomw for the WebSocket data parsing code
* @Cobra for original inspiration on driver version checking
* @user2371 for letting me know about Hubitat adding the uploadHubFile command so images can now be captured
*/

import groovy.json.JsonSlurper
import groovy.transform.Field

@Field static final String DRIVER = "UnifiProtectAPI"
// Returns the driver name
def DriverName(){
    return "UnifiProtectAPI"
}

@Field static final String VERSION = "0.2.79"
// Returns the driver version
public static String version(){
    return "0.2.79"
}

@Field static def slurper = new JsonSlurper()
@Field static Number procTime = 0
@Field static Number callCount = 0
@Field static def deviceLookup = [:]

// Driver Metadata
metadata{
	definition( name: "UnifiProtectAPI", namespace: "Snell", author: "David Snell", importUrl: "https://www.drdsnell.com/projects/hubitat/drivers/UnifiProtectAPI.groovy" ) {
		// Indicate what capabilities the device should be capable of
		capability "Sensor"
		capability "Refresh"
        capability "Actuator"
        capability "TemperatureMeasurement"
        
        // Commands
        //command "DoSomething" // Does something for development/testing purposes, should be commented before publishing
        //command "ConnectWebSocket" // Connect to the controller for WebSocket notices
        //command "CloseWebSocket" // Connect to the controller for WebSocket notices
        command "Login" // Logs in to the controller to get a cookie for the session
        command "GetSnapshot", [ [ name: "CameraID*", type: "STRING", description: "REQUIRED: Camera ID to get snapshot from" ] ]
        
		// WebHook command from @Mavrrick58
        command "ApplyWebHook", [ [ name: "DeviceID*", type: "STRING", description: "Camera ID to apply Webhook event to" ],
                          [ name: "WebHookType*", type: "STRING", description: "Attribute/Event name" ],
                          [ name: "WebHookValue", type: "STRING", description: "Attribute/Event value" ] ]

        // Unifi Protect related commands
        command "GetProtectInfo" // Checks for general data on the Protect controller, same as refresh
        command "Reboot", [
            [ name: "Confirmation", type: "STRING", description: "Type the word Reboot to confirm intent to reboot the controller." ]
        ] // Submits a reboot command to the controller.
        // System level commands
        command "PowerDown", [
            [ name: "Confirmation", type: "STRING", description: "Type the word PowerDown to confirm intent to power down the controller." ]
        ] // Submits a shutdown command to the controller.
        
        // API Methods Not Implemented
        // "api/events?end=EPOCH&start=EPOCH" // Appears to be able to show events between a range of epoch-based times
        // "api/backups" // 
        // "api/cameras" // May show camera data
        command "GetMotionEvents", [ [ name: "Number*", type: "ENUM", description: "REQUIRED: Number of events to get", defaultValue: 10, constraints: [ 1, 5, 10, 25, 50, 100 ] ] ]
        
        command "ResetWebSocket" // Meant to reset the websocket connection to the controller
        
		// Attributes for the driver itself
		attribute "DriverName", "string" // Identifies the driver being used for update purposes
		attribute "DriverVersion", "string" // Handles version for driver
        attribute "DriverStatus", "string" // Handles version notices for driver
        
        // Attributes for the device
        attribute "Status", "string" // Show success/failure of commands performed
        attribute "LastLogin", "string" // Shows when the last login was performed
        attribute "LastRefresh", "string" // Shows when the last refresh was performed
        attribute "LastUpdatedID", "string" // Shows the ID for the last update from the bootstrap
        attribute "WebSocketDelay", "number"
        attribute "WebSocketStatus", "string"
        attribute "WebSocketOpen", "bool"
        attribute "CPULoad", "number"
        attribute "avgTime", "number"
    }
	preferences{
		section{
            if( ShowAllPreferences || ShowAllPreferences == null ){ // Show the preferences options
                input( type: "enum", name: "RefreshRate", title: "<b>Stats Refresh Rate</b>", required: true, multiple: false, options: [ "5 minutes", "10 minutes", "15 minutes", "30 minutes", "1 hour", "3 hours", "Manual" ], defaultValue: "15 minutes" )
                input( type: "bool", name: "EnableWebSocket", title: "<b>Enable WebSocket Monitoring</b></br><font size='2'>Required for notification rather than polling of device events</font>", required: false, defaultValue: true )
    			input( type: "enum", name: "LogType", title: "<b>Enable Logging?</b>", required: false, multiple: false, options: [ "None", "Info", "Debug", "Trace" ], defaultValue: "Info" )
                input( type: "enum", name: "Controller", title: "<font color='FF0000'><b>Unifi Controller Type</b></font>", required: true, multiple: false, options: [ "Unifi Dream Machine (inc Pro)", "Other Unifi Controllers" ], defaultValue: "Unifi Dream Machine (inc Pro)" )
                if( Controller == "Other Unifi Controllers" ){
				    input( type: "string", name: "ControllerPort", title: "<font color='FF0000'><b>Controller Port #</b></font>", defaultValue: "7443", required: true )
                }
                input( type: "string", name: "UnifiURL", title: "<font color='FF0000'><b>Unifi Controller IP/Hostname</b></font>", required: true )
				input( type: "string", name: "Username", title: "<font color='FF0000'><b>Username</b></font>", required: true )
				input( type: "password", name: "Password", title: "<font color='FF0000'><b>Password</b></font>", required: true )
                input( type: "bool", name: "ShowAllPreferences", title: "<b>Show All Preferences?</b>", defaultValue: true )
            } else {
                input( type: "bool", name: "ShowAllPreferences", title: "<b>Show All Preferences?</b>", defaultValue: true )
            }
        }
	}
}

// Command to test fixes or other oddities during development
def DoSomething(){
    
}

// Helper routine(s) for other apps and integrations
// This one is to update preferences from @mavrrick58's Integration app
def updateDevSettings (String prefName, String prefDataType, String value){
    device.updateSetting(prefName, [type: "$prefDataType", value: value])
}

// WebHook processing courtesy of @mavrrick58
def ApplyWebHook( String DeviceID, String WebHookType, String WebHookValue = null ){
    if( WebHookValue == null ){
        WebHookValue = "N/A"
    }
    switch( WebHookType ) {
    	case "Face":
        case "LicensePlate":
        case "NFCCardScan":
        case "FingerprintScan":
        case "Sound":
        case "PersonOfInterest":
        case "KnownFace":
        case "UnknownFace":
        case "VehicleOfInterest":
        case "KnownVehicle":
        case "UnknownVehicle":
        case "Person":
        case "Vehicle":
        case "Package":
        case "Animal":
        case "LineCrossing":
        case "Loitering":
        case "DoorbellRings":
        case "Motion":
            Logging( "WebHook: Device ${ DeviceID }, ${ WebHookType } = ${ WebHookValue }", 4 )
            PostEventToChild( "${ DeviceID }", "AIRecognitionType" , "${ WebHookType }" , null )
        	PostEventToChild( "${ DeviceID }", "AIRecognitionValue" , "${ WebHookValue }" , null )
    		break
    default:
        Logging( "Unrecognized WebHook \"${ WebHookType }\" = ${ WebHookValue }, contact developer to add.", 3 )
        break
    }    
}

// REQUIRED: This method is called with any incoming messages from the web socket server.
// Changes to beginning regarding modelKey and events from @blocklanders
/*
def decodedPacket = [
    filter: [ filtering: FilterResult ],
    actionPacket: [ actionHeader: actionHeaderMap, actionPayload: actionJsonMap ],
    dataPacket: [ dataHeader: dataHeaderMap, dataPayload: dataJsonMap ]
]
*/
def parse( String description ){
    if (!deviceLookup) {
        deviceLookupLoad()
    }

    def Data = packetValidateAndDecode( description )
    
    if( Data != null ){
        def modelKey = Data.actionPacket.modelKey
        def EventID
        def TempID
        if( Data.actionPacket.recordId != null ){
            TempID = Data.actionPacket.recordId
            if( TempID != null ){
                if( TempID.indexOf( "-" ) != -1 ){
                    TempID = Data.actionPacket.recordId.split( "-" )
                    EventID = TempID[ 0 ]
                    TempID = TempID[ 1 ]
                } else {
                    EventID = TempID
                }
            }
        } else if( Data.actionPacket.id != null ){
            TempID = Data.actionPacket.id
            if( TempID.indexOf( "-" ) != -1 ){
                TempID = Data.actionPacket.id.split( "-" )
                EventID = TempID[ 0 ]
                TempID = TempID[ 1 ]
            } else {
                EventID = TempID
            }
        } else if( Data.actionPacket.authorizationModelId != null ){
            TempID = Data.actionPacket.authorizationModelId
            EventID = TempID
        } else if( Data.dataPacket?.metadata?.sensorId?.text != null ){
            TempID = Data.dataPacket.metadata.sensorId.text
        }
        def Device
        def LastAction
        def LastActionID
        if( TempID == null ){
            Logging( "No ID found. ${ Data }", 3 )    
        } else {
            if (TempID != null && deviceLookup[TempID]) {
                Device = deviceLookup[TempID]
            }
        }
		if( Device != null ){
            def childDevice = getChildDevice(Device)
            childDevice.childPost(Data)
        }    
    }
}

def formatDuration(long milliseconds) {
    if (milliseconds < 1000) {
        return "${milliseconds} ms"
    }

    long seconds = milliseconds / 1000
    if (seconds < 60) {
        return "${seconds} s ${milliseconds % 1000} ms"
    }

    long minutes = seconds / 60
    if (minutes < 60) {
        return "${minutes} min ${seconds % 60} s ${milliseconds % 1000} ms"
    }

    long hours = minutes / 60
    return "${hours} h ${minutes % 60} min ${seconds % 60} s ${milliseconds % 1000} ms"
}

// Beggining of @tomw's code (with minor changes)
import java.io.ByteArrayOutputStream
import java.util.zip.Inflater
import groovy.transform.Field

// REQUIRED: This method is called with any status messages from the web socket client connection (disconnections, errors during connect, etc)
def webSocketStatus( String Response ){
    //Logging( "WebSocketStatus = ${ Response } at ${ ConvertEpochToDate( new Date().time as String ) }", 3 )
    
    // @tomw: thanks for the idea: https://community.hubitat.com/t/websocket-client/11843/15
    if( Response.startsWith( "status: open" ) ){
        ProcessState( "WebSocketOpen", true )
        ProcessState( "WebSocketStatus", "OK" )
        ProcessState( "WebSocketFailures", 0 )
        unschedule( "initialize" )
    } else if( Response.startsWith( "status: closing" ) ){
        ProcessState( "WebSocketOpen", false )
        ProcessState( "WebSocketStatus", "Closing" )
        reinitialize()
    } else if( Response.startsWith( "failure:" ) ){
        Logging( "WebSocket Failure: ${ Response }", 5 )
        ProcessState( "WebSocketOpen", false )
        ProcessState( "WebSocketStatus", "Failure" )
        ProcessState( "WebSocketFailures", ( state.WebSocketFailures + 1 ) )
        reinitialize()
    } else {
        Logging( "WebSocket Error: ${ Response }", 5 )
        ProcessState( "WebSocketOpen", false )
        ProcessState( "WebSocketStatus", "Error" )
        ProcessState( "WebSocketFailures", ( state.WebSocketFailures + 1 ) )
        reinitialize()
    }
}


// Command to reset the WebSocket interface
def ResetWebSocket(){
    ProcessState( "WebSocketDelay", 15 )
    reinitialize()
}

// Thanks @tomw for most of websocket code (with some modification)
// Create a WebSocket connection to monitor for events
def ConnectWebSocket(){
    //Logging( "Connecting Socket at ${ ConvertEpochToDate( new Date().time as String ) }", 3 )
    if( EnableWebSocket ){
        try{
            if( Controller == "Unifi Dream Machine (inc Pro)" ){
                interfaces.webSocket.connect( "wss://${ UnifiURL }/proxy/protect/ws/updates?lastUpdateId=${ state.LastUpdatedID }", ignoreSSLIssues: true, headers: [ Host: "${ UnifiURL }", Accept: "*/*", Cookie: "${ state.Cookie }", 'X-CSRF-Token': "${ state.CSRF }", 'accessKey': "${ state.AuthKey }" ], pingInterval: 30 )
            } else {
                interfaces.webSocket.connect( "wss://${ UnifiURL }:${ ControllerPort }/ws/updates?lastUpdateId=${ state.LastUpdatedID }", ignoreSSLIssues: true, headers: [ Host: "${ UnifiURL }", Accept: "*/*", Cookie: "${ state.Cookie }", 'X-CSRF-Token': "${ state.CSRF }", 'accessKey': "${ state.AuthKey }" ], pingInterval: 30 )
            }
            ProcessState( "WebSocketOpen", true )
    		ProcessState( "WebSocketStatus", "OK" )
        	ProcessState( "WebSocketFailures", 0 )
            ProcessState( "WebSocketOpenedAt", new Date().time )
        }
        catch( Exception e ){
            Logging( "Exception when opening WebSocket: ${ e }", 5 )
            ProcessState( "WebSocketStatus", "Error" )
            ProcessState( "WebSocketFailures", ( state.WebSocketFailures + 1 ) )
        }
    }
}

// Close the WebSocket connection
def CloseWebSocket(){
    //Logging( "Closing Socket at ${ ConvertEpochToDate( new Date().time as String ) }", 3 )
    unschedule( initialize )
    if( WebSocketOpen ){
    	try{
            ProcessState( "WebSocketStatus", "Closing" )
        	pauseExecution( 500 )
        	interfaces.webSocket.close()
        	ProcessState( "WebSocketOpen", false )
    		ProcessState( "WebSocketStatus", "Closed" )
        	ProcessState( "WebSocketFailures", 0 )
        	ProcessState( "WebSocketClosedAt", new Date().time )
    	}
    	catch( Exception e ){
        	Logging( "Exception when closing WebSocket: ${ e }", 5 )
        	ProcessState( "WebSocketStatus", "WebSocket close error" )
        	ProcessState( "WebSocketFailures", ( state.WebSocketFailures + 1 ) )
        }
    } else {
        ProcessState( "WebSocketStatus", "Closed" )
    }
}

// Send a WebSocket message, if needed at some point
def SendWebSocketMessage( String Message ){
    try{
        interfaces.webSocket.sendMessage( Message )
    }
    catch( Exception e ){
        Logging( "Exception when sending WebSocket message: ${ e }", 5 )
        ProcessState( "WebSocketStatus", "WebSocket message error" )
        ProcessState( "WebSocketFailures", ( state.WebSocketFailures + 1 ) )
    }
}

def reinitialize(){
    // thanks @ogiewon for the original example
    if( state.WebSocketDelay == null ){
        ProcessState( "WebSocketDelay", 15 )
    }
    //Logging( "Reinitializing with a ${ state.WebSocketDelay } second delay", 3 )
    ProcessState( "WebSocketStatus", "Reinitializing" )
    runIn( state.WebSocketDelay, initialize )

    // upper limit is 600s
    if( ( state.WebSocketDelay * 2 ) > 600 ){
        ProcessState( "WebSocketDelay", 600  )
    } else {
    	ProcessState( "WebSocketDelay", ( state.WebSocketDelay * 2 )  )
    }
}

def initialize(){
    //Logging( "Reinit called at ${ ConvertEpochToDate( new Date().time as String ) }", 3 )
    CloseWebSocket()
    pauseExecution( 1000 )
    if( EnableWebSocket ){
        ConnectWebSocket()
    }
}

private decompress( s ){
    // based on this example: https://dzone.com/articles/how-compress-and-uncompress    
    def sBytes = hubitat.helper.HexUtils.hexStringToByteArray( s )
    
    Inflater inflater = new Inflater() 
    inflater.setInput( sBytes )
    
    ByteArrayOutputStream outputStream = new ByteArrayOutputStream( sBytes.length )
    
    byte[] buffer = new byte[ 1024 ]
    
    while( !inflater.finished() ){  
        int count = inflater.inflate( buffer )
        outputStream.write( buffer, 0, count )
    }
    
    outputStream.close()
    
    def resp = new String( outputStream.toByteArray() )    
    
    return resp
}

private subBytes( arr, start, length ){
    return arr.toList().subList( start, start + length ) as byte[]
}

private repackHeaderAsMap( header ){
    def headerMap = [
            packetType: subBytes( header, 0, 1 ),
            payloadFormat: subBytes( header, 1, 1 ),
            deflated: subBytes( header, 2, 1 ),
            payloadSize: hubitat.helper.HexUtils.hexStringToInt( hubitat.helper.HexUtils.byteArrayToHexString( subBytes( header, 4, 4 ) ) )
        ]
}

def encHexMacro( string ){
    return string.getBytes()?.encodeHex()?.toString()
}

@Field String actionAdd        = encHexMacro( '"action":"add"' )
@Field String actionUpdate     = encHexMacro( '"action":"update"' )
@Field String modelKeyCamera   = encHexMacro( '"modelKey":"camera"' )
@Field String modelKeyChime    = encHexMacro( '"modelKey":"chime"' )
@Field String modelKeyEvent    = encHexMacro( '"modelKey":"event"' )
@Field String modelKeyLight    = encHexMacro( '"modelKey":"light"' )
@Field String modelKeyViewer   = encHexMacro( '"modelKey":"viewer"' )
@Field String modelKeySensor   = encHexMacro( '"modelKey":"sensor"' )
@Field String modelKeyNVR      = encHexMacro( '"modelKey":"nvr"' )
@Field String modelKeyUser     = encHexMacro( '"modelKey":"user"' )
@Field String modelKeyBridge   = encHexMacro( '"modelKey":"bridge"' )
@Field String modelKeyLinkstation = encHexMacro( '"modelKey":"linkstation"' )
@Field String modelKeyAutomation = encHexMacro( '"modelKey":"automation"' )
@Field String modelKeyAuthorization = encHexMacro( '"authorizationModelKey":"camera"' )
@Field String modelKeyactiveSessionStat = encHexMacro( '"modelKey":"activeSessionStat"' )

@Field String eventValueRing            = encHexMacro( '"ring"' )
@Field String isDarkKey                 = encHexMacro( '"isDark"' )
@Field String isLightOnKey              = encHexMacro( '"isLightOn"' )
@Field String isMotionDetectedKey       = encHexMacro( '"isMotionDetected"' )
@Field String isPirMotionDetectedKey    = encHexMacro( '"isPirMotionDetected"' )
@Field String isSmartDetectedKey        = encHexMacro( '"isSmartDetected"' )
@Field String lcdMessageKey             = encHexMacro( '"lcdMessage"' )
@Field String ledSettingsKey            = encHexMacro( '"ledSettings"' )
@Field String lightDeviceSettingsKey    = encHexMacro( '"lightDeviceSettings"' )
@Field String liveviewKey               = encHexMacro( '"liveview"' )
@Field String smartDetectTypesKey       = encHexMacro( '"smartDetectTypes"' )
@Field String volumeKey                 = encHexMacro( '"volume"' )
@Field String bodyKey                   = encHexMacro( '"_body"' )

def coarsePacketValidate( localStr ){
    // Beware: this is coarse and potentially brittle.  Check here first if you are not seeing packets that you think you should!
    
    // Before doing any other processing, try to determine if this packet contains useful updates.
    // This is to limit the processing utilization on Hubitat since the Protect controller is so chatty.    
    
    // The groupings appear to be based on here: https://github.com/hjdhjd/unifi-protect/blob/main/src/protect-api-events.ts
//    def localStr = hexString?.toLowerCase()
    if( !localStr ){ return null }
    
    def searchList
    
    if( localStr.contains( modelKeyEvent ) ){
        // "event"
        searchList = [ eventValueRing ]
    }
    if( localStr.contains( smartDetectTypesKey ) ){
        searchList = [ smartDetectTypesKey ]
    }
    if( localStr.contains( modelKeyCamera ) && localStr.contains( actionUpdate ) ){
        // "camera" and "update"
        searchList = [ isDarkKey, isMotionDetectedKey, isSmartDetectedKey, lcdMessageKey, ledSettingsKey ]
    }
    if( localStr.contains( modelKeyChime ) && localStr.contains( actionUpdate ) ){
        // "chime" and "update"
        searchList = [ volumeKey ]
    }
    if( localStr.contains( modelKeyLight ) && localStr.contains( actionUpdate ) ){
        // "light" and "update"
        searchList = [ isDarkKey, isLightOnKey, isMotionDetectedKey, isPirMotionDetectedKey, lightDeviceSettingsKey ]
    }
    if( localStr.contains( modelKeySensor ) && localStr.contains( actionUpdate ) ){
        // "sensor" and "update"
        searchList = [ isDarkKey, isLightOnKey, isMotionDetectedKey, isPirMotionDetectedKey ]
    }
    if( localStr.contains( modelKeyViewer ) && localStr.contains( actionUpdate) ){
        // "liveview" and "update"
        searchList = [ liveviewKey ]
    }
    if( localStr.contains( modelKeyUser ) && localStr.contains( actionUpdate) ){
        // "user" and "update"
        searchList = [ modelKeyUser ] // Ignore users at this time
    }
    if( localStr.contains( modelKeyNVR ) && localStr.contains( actionUpdate) ){
        // "nvr" and "update"
        searchList = [ modelKeyNVR ] // Ignore NVR specific updates
    }
    if( localStr.contains( bodyKey ) && localStr.contains( actionUpdate) ){
        // "_body" and "update"
        searchList = [ bodyKey ] // Ignore the _body updates
    }
    if( localStr.contains( modelKeyBridge ) && localStr.contains( actionUpdate) ){
        // "bridge" and "update"
        searchList = [ modelKeyBridge ] //
    }
    if( localStr.contains( modelKeyLinkstation ) && localStr.contains( actionUpdate) ){
        // "linkstation" and "update"
        searchList = [ modelKeyLinkstation ]
    }
    if( localStr.contains( modelKeyAutomation ) && localStr.contains( actionUpdate) ){
        // "automation" and "update"
        searchList = [ modelKeyAutomation ]
    }
    if( localStr.contains( modelKeyAuthorization ) && localStr.contains( actionAdd) ){
        // "Authorization" and "add"
        searchList = [ modelKeyAuthorization ]
    }
    if( localStr.contains( modelKeyactiveSessionStat ) && localStr.contains( actionUpdate) ){
        // "activeSessionStat" and "update"
        searchList = [ modelKeyactiveSessionStat ]
    }
    //return searchList?.any { localStr.contains( it ) }
    if( !searchList ){
        def Split = ( new String( hubitat.helper.HexUtils.hexStringToByteArray( localStr ) ) ).split( "," )
        //Logging( "Split Packet Drop = ${ Split }", 3 )
    }
    return searchList
}

/*
  Things that appear to have limited value or are just regularly sent WSS
  @mavrrick58. This doesn't seem to work because the string formating is different. 
  Strings needed to be updated with " around each item to match hex string. Them compare code needed to be updated to compare against source hex string. 
*/
@Field String IgnoreKey1				= encHexMacro( '"modifiedKeys":["lastSeen,"nvrMac"]' )
@Field String IgnoreKey2				= encHexMacro( '"modifiedKeys":["stats","nvrMac"]' )
@Field String IgnoreKey3				= encHexMacro( '"modifiedKeys":["phyRate","wifiConnectionState","stats","nvrMac"]' )
@Field String IgnoreKey4				= encHexMacro( '"modifiedKeys":["upSince","uptime","lastSeen","uplinkDevice","wifiConnectionState","nvrMac"]' )
@Field String IgnoreKey5				= encHexMacro( '"modifiedKeys":["wifiConnectionState","nvrMac"]' )


private packetValidateAndDecode( hexString ){    
    def localStr = hexString?.toLowerCase()
    def FilterResult = coarsePacketValidate( localStr )
    if( !FilterResult ){
        def Split = ( new String( hubitat.helper.HexUtils.hexStringToByteArray( hexString ) ) ).split( "," )
        def Action = Split[ 0 ] as String
        Logging( "WSS Unidentified Packet ${ Action } for ${ Split[ 2 ] }", 4 )
        return
    } else if( FilterResult.contains( bodyKey ) ){
        Logging( "WSS Ignoring _body packets", 4 )
        return
    } else if( FilterResult.contains( modelKeyNVR ) ){
        Logging( "WSS Ignoring NVR packets", 4 )
        return
    } else if( FilterResult.contains( modelKeyUser ) ){
        Logging( "WSS Ignoring User packets", 4 )
        return
    } else if( FilterResult.contains( modelKeyBridge ) ){
        Logging( "WSS Ignoring Bridge packets", 4 )
        return
    } else if( FilterResult.contains( modelKeyLinkstation ) ){
        Logging( "WSS Ignoring Linkstation packets", 4 )
        return
    } else if( FilterResult.contains( modelKeyactiveSessionStat ) ){
        Logging( "WSS Ignoring modelKeyactiveSessionStat packets", 4 )
        return
    } else if( localStr.contains( IgnoreKey1 ) ){
        Logging( "WSS Ignoring packets that are just lastSeeen and nvrMac", 4 )
        return
    } else if( localStr.contains( IgnoreKey2 ) ){
        Logging( "WSS Ignoring packets that are just stats and nvrMac", 4 )
        return
    } else if( localStr.contains( IgnoreKey3 ) ){
        Logging( "WSS Ignoring packets that are just phyRate, wifiConnectionState, stats and nvrMac", 4 )
        return
    } else if( localStr.contains( IgnoreKey4 ) ){
        Logging( "WSS Ignoring packets that are just upSince, uptime, lastSeen, uplinkDevice, wifiConnectionState, nvrMac", 4 )
        return
    } else if( localStr.contains( IgnoreKey5 ) ){
        Logging( "WSS Ignoring packets that are just wifiConnectionState, nvrMac", 4 )
        return    
    } else if( FilterResult.contains( modelKeyAutomation ) ){
        Logging( "WSS Ignoring packets that are from automation", 4 )
        return
    }
    
    
    
    // all of this is based on the packet formats described here:  https://github.com/hjdhjd/unifi-protect/blob/main/src/protect-api-events.ts
    def actionHeader
    def actionLength
    def dataHeader
    def dataLength
    
    def bytes
    
    //
    // first, basic packet validation
    //
    
    try{
        bytes = hubitat.helper.HexUtils.hexStringToByteArray( hexString )
        
        actionHeader = subBytes( bytes, 0, 8 )
        actionLength = hubitat.helper.HexUtils.hexStringToInt(hubitat.helper.HexUtils.byteArrayToHexString( subBytes( actionHeader, 4, 4 ) ) )
        dataHeader = subBytes( bytes, actionHeader.size() + actionLength, 8 )
        dataLength = hubitat.helper.HexUtils.hexStringToInt(hubitat.helper.HexUtils.byteArrayToHexString( subBytes( dataHeader, 4, 4 ) ) )
        
        def totalLength = actionHeader.size() + actionLength + dataHeader.size() + dataLength
        
        if( totalLength != bytes.size() ){
            throw new Exception("Header/Packet mismatch.")
        }
    }
    catch( Exception e ){
        Logging( "Packet validation failed: ${ e.message }", 5 )
        // any error interpreted as fail
        return null
    }
    
    //
    // then, decode and re-pack data
    //
    
    try{
        def actionHeaderMap = repackHeaderAsMap( actionHeader )
        def dataHeaderMap = repackHeaderAsMap( dataHeader )
        
        def actionPacket = hubitat.helper.HexUtils.byteArrayToHexString( subBytes( bytes, actionHeader.size(), actionHeaderMap.payloadSize ) )  
        def dataPacket = hubitat.helper.HexUtils.byteArrayToHexString( subBytes( bytes, actionHeader.size() + actionLength + dataHeader.size(), dataHeaderMap.payloadSize ) )
        
        def actionJson = actionHeaderMap.deflated?.getAt( 0 ) ? decompress( actionPacket ) : makeString( actionPacket )
        def actionJsonMap = slurper.parseText( actionJson?.toString() )
        
        def dataJson = dataHeaderMap.deflated?.getAt( 0 ) ? decompress( dataPacket ) : makeString( dataPacket )
        def dataJsonMap = slurper.parseText( dataJson?.toString() )
        
        def decodedPacket = [
            //actionPacket: [ actionHeader: actionHeaderMap, actionPayload: actionJsonMap ], // actionHeader Sample = actionHeader:[packetType:[1], payloadFormat:[1], deflated:[0], payloadSize:259]
            actionPacket: actionJsonMap,
            //dataPacket: [ dataHeader: dataHeaderMap, dataPayload: dataJsonMap ] // dataHeader Sample = dataHeader:[packetType:[2], payloadFormat:[1], deflated:[0], payloadSize:504]
            dataPacket: dataJsonMap
        ]
        Logging( "Decoded WSS = ${ decodedPacket }", 4 )
        return decodedPacket
    }
    catch (Exception e)
    {
        Logging( "Packet decoding failed: ${ e.message }", 5 )
        // any error interpreted as fail
        return null
    }
}

private makeString(s){
    return new String(hubitat.helper.HexUtils.hexStringToByteArray(s))
}
// End of @tomw's code

// updated is called whenever device parameters are saved
def updated(){
    // Set the driver name and version
    ProcessEvent( "DriverName", DriverName() )
    ProcessEvent( "DriverVersion", version() )
    ProcessEvent( "DriverStatus", null )
    
    // Set the default logging to info if it was not already configured
    if( LogType == null ){
        LogType = "Info"
    }
    // Set the default controller if it was not configured
    if( Controller == null ){
        Controller = "Unifi Dream Machine (inc Pro)"
    } else if( ( Controller == "Other Unifi Controllers" ) && ( ControllerPort == null) ){
        // Set the default controller port if using other types of Unifi controllers
        ControllerPort = "7443"
    }
    
    // Reset LoginRetries counter
    ProcessState( "LoginRetries", 0 )
    
    // Set regularly scheduled tasks
    SetScheduledTasks()
    
    // WebSocket settings
    ProcessState( "WebSocketFailures", 0 )
    ProcessState( "WebSocketDelay", 15 )
    if( EnableWebSocket ){
        ConnectWebSocket()
    } else {
        CloseWebSocket()
    }
    
    Logging( "Updated preferences saved", 2 )
}

// refresh performs a poll of data
def refresh(){   
    GetProtectInfo()
    ProcessState( "LastRefresh", new Date() )
}

// Set scheduled tasks
def SetScheduledTasks(){
    unschedule()
    // Schedule a login every 10 minutes
    def Hour = ( new Date().format( "h" ) as int )
    def Minute = ( new Date().format( "m" ) as int )
    def Second = ( new Date().format( "s" ) as int )
    Second = ( (Second + 5) % 60 )
    schedule( "${ Second } 0/10 * ? * *", "Login" )
        
    // Check what the refresh rate is set for then run it
    switch( RefreshRate ){
        case "1 minute": // Schedule the refresh check for every minute
            schedule( "${ Second } * * ? * *", "refresh" )
            break
        case "5 minutes": // Schedule the refresh check for every 5 minutes
            schedule( "${ Second } 0/5 * ? * *", "refresh" )
            break
        case "10 minutes": // Schedule the refresh check for every 10 minutes
            schedule( "${ Second } 0/10 * ? * *", "refresh" )
            break
        case "15 minutes": // Schedule the refresh check for every 15 minutes
            schedule( "${ Second } 0/15 * ? * *", "refresh" )
            break
        case "30 minutes": // Schedule the refresh check for every 30 minutes
            schedule( "${ Second } 0/30 * ? * *", "refresh" )
            break
        case "1 hour": // Schedule the refresh check for every hour
            schedule( "${ Second } ${ Minute } * ? * *", "refresh" )
            break
        case "3 hours": // Schedule the refresh check for every 3 hours
            schedule( "${ Second } ${ Minute } 0/3 ? * *", "refresh" )
            break
        default:
            RefreshRate = "Manual"
            break
    }
    Logging( "Refresh rate: ${ RefreshRate }", 4 )
    
    // Schedule check(s) that are only performed once a day
    schedule( "${ Second } ${ Minute } ${ Hour } ? * *", "CheckForUpdate" )
}

//Log in to Unifi
def Login( Manual = true ){
    def Params
    if( Manual || ( state.LoginRetries < 5 ) ){
        if( Controller == "Unifi Dream Machine (inc Pro)" ){
            Params = [ uri: "https://${ UnifiURL }/api/auth/login", ignoreSSLIssues: true, requestContentType: "application/json", contentType: "application/json", body: "{\"username\":\"${ Username }\",\"password\":\"${ Password }\",\"remember\":\"true\"}", headers: [ 'X-CSRF-Token': state.CSRF ] ]
        } else {
            Params = [ uri: "https://${ UnifiURL }:${ ControllerPort }/api/login", ignoreSSLIssues: true, requestContentType: "application/json", contentType: "application/json", body: "{\"username\":\"${ Username }\",\"password\":\"${ Password }\",\"remember\":\"true\"}", headers: [ 'X-CSRF-Token': state.CSRF ] ]
        }
        //Logging( "Login Parameters = ${ Params }", 3 )
        try{
            httpPost( Params ){ resp ->
                //Logging( "Login response = ${ resp.data }", 3 )
	            switch( resp.getStatus() ){
		            case 200:
                        if( state.LoginRetries > 0 ){
                            ProcessState( "LoginRetries", 0 )
                            SetScheduledTasks()
                        }
                        if( Manual && EnableWebSocket ){
                            ResetWebSocket()
                        }
                        ProcessEvent( "Status", "Login successful." )
                        ProcessState( "LastLogin", new Date() )
                        def Cookie
                        resp.getHeaders().each{
                        if( ( it.value.split( '=' )[ 0 ].toString() == "unifises" ) || ( it.value.split( '=' )[ 0 ].toString() == "TOKEN" ) || ( it.value.split( '=' )[ 0 ].toString() == "UOS_TOKEN" ) ){
                                Cookie = resp.getHeaders().'Set-Cookie'
                                if( Controller == "Unifi Dream Machine (inc Pro)" ){
                                    Cookie = Cookie.split( ";" )[ 0 ] + ";"
                                } else {
                                    Cookie = Cookie.split( ";" )[ 0 ]
                                }
                                ProcessState( "Cookie", Cookie )
                            } else {
                                def CSRF
                                if( Controller == "Unifi Dream Machine (inc Pro)" ){
                                    CSRF = it as String
                                    if( CSRF.split( ':' )[ 0 ].toUpperCase() == "X-CSRF-TOKEN" ){
                                       ProcessState( "CSRF", it.value )
                                   }
                                } else {
                                    if( it.value.split( '=' )[ 0 ].toString() == "csrf_token" ){
                                        CSRF = it.value.split( ';' )[ 0 ].split( '=' )[ 1 ]
                                        ProcessState( "CSRF", CSRF )
                                    }
                                }
                            }
                        }
                        asynchttpPost( "ReceiveData", GenerateProtectParams( "api/auth/access-key" ), [ Method: "AuthKey" ] )
			            break
                    case 403:
                        Logging( "Login failure: Forbidden", 5 )
                        ProcessEvent( "Status", "Login failure" )
                        ProcessState( "LoginRetries", ( state.LoginRetries + 1 ) )
			            break
                    case 404:
                        Logging( "Login failure: Not found", 5 )
                        ProcessEvent( "Status", "Login failure" )
                        ProcessState( "LoginRetries", ( state.LoginRetries + 1 ) )
			            break
                    case 408:
                        Logging( "Login failure: Request Timeout", 5 )
                        ProcessEvent( "Status", "Login failure" )
                        ProcessState( "LoginRetries", ( state.LoginRetries + 1 ) )
			            break
		            default:
			            Logging( "Error logging in to controller: ${ resp.status }", 5 )
                        ProcessEvent( "Status", "Login failure" )
                        ProcessState( "LoginRetries", ( state.LoginRetries + 1 ) )
			            break
	            }
            }
        } catch( Exception e ){
            if( state.LoginRetries > 5 ){
                Logging( "Too many login failures. Please confirm the local username & password and perform a manual login.", 5 )
                ProcessEvent( "Status", "Login failure, check account information and perform manual login." )
                unschedule( "Login" )
                unschedule( "refresh" )
            } else {
                def Temp = "${ e }"
                Logging( "Temp Login Status = ${ Temp }", 4 )
                if( Temp.split( "status code: " ).size() > 1 ){
                    def StatusCode = Temp.split( "status code: " )[ 1 ].split( "," )[ 0 ]
                    switch( StatusCode as int ){
                        case 403:
                            Logging( "Forbidden", 5 )
                            ProcessEvent( "Status", "Login failure" )
                            ProcessState( "LoginRetries", ( state.LoginRetries + 1 ) )
                            break
                        case 404:
                            Logging( "Not found", 5 )
                            ProcessEvent( "Status", "Login failure" )
                            ProcessState( "LoginRetries", ( state.LoginRetries + 1 ) )
                            break
                        case 408:
                            Logging( "Request Timeout", 5 )
                            ProcessEvent( "Status", "Login failure" )
                            ProcessState( "LoginRetries", ( state.LoginRetries + 1 ) )
                            break
                        case 499:
                            Logging( "Connection Closed - Likely due to MFA, please confirm Login without MFA method", 5 )
                            ProcessEvent( "Status", "MFA Login Required" )
                            //ProcessState( "LoginRetries", ( state.LoginRetries + 1 ) )
                            break
                        default:
                            Logging( "Error logging in to controller: ${ e }", 5 )
                            ProcessEvent( "Status", "Login failure" )
                            ProcessState( "LoginRetries", ( state.LoginRetries + 1 ) )
                            break
                    }
                } else {
                    Logging( "Login error with no status information - Likely due to MFA, please confirm Login without MFA method", 5 )
                }
            }
        }
    } else {
        Logging( "Too many login failures. Please confirm the local username & password and perform a manual login.", 5 )
        ProcessEvent( "Status", "Login failure, check account information and perform manual login." )
    }
}

// Command to attempt to get general Protect info
def GetProtectInfo(){
    def Attempt = "api/bootstrap"
    asynchttpGet( "ReceiveData", GenerateProtectParams( "${ Attempt }" ), [ Method: "Bootstrap" ] )
}

// Attempts to get a list of motion-based events
def GetMotionEvents( Number ){
    def Attempt = "api/events?allCameras=true&end&limit=${ Number }&orderDirection=DESC&start&types=motion&types=smartDetectZone&types=smartDetectLine&types=ring"
    Logging( "Attempting to get ${ Number } motion events", 4 )
    asynchttpGet( "ReceiveData", GenerateProtectParams( "${ Attempt }" ), [ Method: "GetMotionEvents", Number: "${ Number }" ] ) 
}

def GetSnapshot( String CameraID, String DNI = null ){
    if( DNI == null ){
        getChildDevices().each{
			if( CameraID == getChildDevice( it.deviceNetworkId ).ReturnState( "ID" ) ){
				DNI = it.deviceNetworkId
			}
		}
    }
    Method = "GetSnapshot"
    DNI = "${ DNI }"
    Camera = "${ CameraID }"
    def Attempt = "api/cameras/${ Camera }/snapshot"
    Logging( "Attempting GetSnapshot for ${ Camera }", 4 )
	Params = GenerateProtectImageParams( "${ Attempt }" )
    try{
        httpGet( Params ){ resp ->
            switch( resp.getStatus() ){
                case 200:
                    ProcessEvent( "Status", "${ Method } successful." )
                	if( resp.data ){
                    	ByteArrayOutputStream ByteByByte = new ByteArrayOutputStream()
                    	ResponseBytes = resp.data.getBytes()
                    	ByteByByte.write( ResponseBytes )
                    	FileData = ByteByByte.toByteArray()
                    	Filename = "Camera_${ Camera }_Image.jpg"

                    	uploadHubFile( Filename, FileData )
                        PostEventToChild( "${ DNI }", "ImageAsOf", new Date(), null )
                    	PostEventToChild( "${ DNI }", "image", "http://${ location.hub.localIP }/local/${ Filename }", null )
                        PostEventToChild( "${ DNI }", "imageUrl", "http://${ location.hub.localIP }/local/${ Filename }", null )
                        PostEventToChild( "${ DNI }", "Thumbnail", "<img width=\"20%\" height=\"20%\" src=\"http://${ location.hub.localIP }/local/${ Filename }\">" )
                    } else {
                        Logging( "${ Method } response is blank", 3 )
                    }
                    break
                case 400: // Bad request
                    ProcessEvent( "Status", "${ Method } Bad Request" )
                    Logging( "Bad Request for ${ Method }", 5 )
                    break
                case 401:
                    ProcessEvent( "Status", "${ Method } Unauthorized, please Login again" )
                    Logging( "Unauthorized for ${ Method } please Login again", 5 )
                    break
                case 404:
                    ProcessEvent( "Status", "${ Method } Page not found error" )
                    Logging( "Page not found for ${ Method }", 5 )
                    break
                case 408:
                    ProcessEvent( "Status", "Request timeout for ${ Method }" )
                    Logging( "Timeout for ${ Method } headers = ${ resp.getHeaders() }", 4 )
                    break
                default:
                    ProcessEvent( "Status", "Error ${ resp.status } connecting for ${ Method }" )
                    Logging( "Error connecting to Unifi Controller: ${ resp.status } for ${ Method }", 5 )
                    break
            }
        }
    } catch( Exception e ){
    	Logging( "Exception getting snapshot: ${ e }", 5 )
    }
}
                
// Receive general data from the controller
def ReceiveData( resp, data ){
    Logging( "${ resp.getStatus() } = Received ${ data }", 4 )
    switch( resp.getStatus() ){
		case 200:
            def Json = parseJson( resp.data )
            ProcessEvent( "Status", "${ data.Method } successful." )
            switch( data.Method ){
                case "AuthKey":
                    ProcessState( "AuthKey", "${ Json.accessKey }" )
                    break
                case "Bootstrap":
                    ProcessState( "LastUpdatedID", Json.lastUpdateId )
                    Json.cameras.each(){
                        Logging( "Camera data = ${ it }", 4 )
                        def DeviceType
                        switch( it.type ){
                            case "UVC G4 Doorbell Pro PoE": // G4 Doorbell Pro PoE
                            case "UVC G4 Doorbell Pro": // G4 Doorbell Pro
                            case "UVC G4 Doorbell": // G4 Doorbell
                                DeviceType = "Doorbell"
                                break
                            case "UVC G4 PTZ": // Camera G4 PTZ
                            case "UVC G5 PTZ": // Camera G5 PTZ
                                DeviceType = "PTZCamera"
                                break
                            case "UVC G4 Instant": // Camera G4 Instant
                            case "UVC G4 Flex": // Camera G4 Flex
                            case "UVC G3 Instant": // Camera G3 Instant
                            case "UVC G3 Flex": // Camera G3 Flex
                            case "UVC G4 PRO": // Camera G4 Pro
                            case "UVC AI Bullet": // Camera AI Bullet
                            case "UVC AI 360": // Camera AI 360
                            case "UVC G3 PRO": // Camera G3 Pro
                            case "UVC G4 BULLET": // Camera G4 Bullet
                            case "UVC G4 DOME": // Camera G4 Dome
                            case "UVC G3 BULLET": // Camera G3 Bullet
                            default:
                                DeviceType = "Camera"
                                if( it.featureFlags.isPtz != null ){
                                    if( it.featureFlags.isPtz ){
                                		DeviceType = "PTZCamera"
                                    }
                                }
                                break
                        }
                        ProcessData( "${ DeviceType } ${ it.mac }", it )
                    }
                    Json.liveviews.each(){ // Ignoring liveviews at this time because there is not much of anything that can be done with them
                        //Logging( "liveviews Unhandled: ${ it }", 4 )
                    }
                    if( Json.nvr.size() >= 1 ){
                        ProcessData( "NVR ${ Json.nvr.mac }", Json.nvr )
                    }
                    Json.viewers.each(){
                        ProcessData( "Viewer ${ it.mac }", it )
                    }
                    Json.displays.each(){
                        ProcessData( "Display ${ it.mac }", it )
                    }
                    Json.lights.each(){
                        ProcessData( "Light ${ it.mac }", it )
                    }
                    Json.bridges.each(){
                        ProcessData( "Bridge ${ it.mac }", it )
                    }
                    Json.sensors.each(){
                        //Logging( "Sensor data for Sensor ${ it.mac } = ${ it }" , 3 )
                        ProcessData( "Sensor ${ it.mac }", it )
                    }
                    Json.doorlocks.each(){
                        ProcessData( "Doorlock ${ it.mac }", it )
                    }
                    break
                case "GetChildStatus":
                    Logging( "GetChildStatus for ${ data.DNI }: ${ resp.data }", 4 )
                    ProcessData( "${ data.DNI  }", Json )
                    break
                case "GetBridgeStatus":
                    Logging( "GetBridgeStatus for ${ data.DNI }: ${ resp.data }", 4 )
                    ProcessData( "${ data.DNI  }", Json )
                    break
                case "GetCameraStatus":
                    Logging( "GetCameraStatus for ${ data.DNI }: ${ resp.data }", 4 )
                    ProcessData( "${ data.DNI  }", Json )
                    break
                case "GetDoorbellStatus":
                    Logging( "GetDoorbellStatus for ${ data.DNI }: ${ resp.data }", 4 )
                    ProcessData( "${ data.DNI  }", Json )
                    break
                case "GetLightStatus":
                    Logging( "GetLightStatus for ${ data.DNI }: ${ resp.data }", 4 )
                    ProcessData( "${ data.DNI  }", Json )
                    break
                case "GetSensorStatus":
                    Logging( "GetSensorStatus for ${ data.DNI }: ${ resp.data }", 4 )
                    ProcessData( "${ data.DNI  }", Json )
                    break
                case "GetMotionEvents":
                    Logging( "GetMotionEvents: ${ resp.data }", 4 )
                    break
                case "SendBridgeSettings":
                    Logging( "SendBridgeSettings for ${ data.DNI }: ${ resp.data }", 4 )
                    ProcessData( "${ data.DNI  }", Json )
                    break
                case "SendCameraSettings":
                    Logging( "SendCameraSettings for ${ data.DNI }: ${ resp.data }", 4 )
                    ProcessData( "${ data.DNI  }", Json )
                    break
                case "SendDoorbellSettings":
                    Logging( "SendDoorbellSettings for ${ data.DNI }: ${ resp.data }", 4 )
                    ProcessData( "${ data.DNI  }", Json )
                    break
                case "DoorbellNotification":
                    Logging( "DoorbellNotification for ${ data.DNI }: ${ resp.data }", 4 )
                    ProcessData( "${ data.DNI  }", Json )
                    break
                case "SendLightSettings":
                    Logging( "SendLightSettings for ${ data.DNI }: ${ resp.data }", 4 )
                    ProcessData( "${ data.DNI  }", Json )
                    break
                case "SendSensorSettings":
                    Logging( "SendSensorSettings for ${ data.DNI }: ${ resp.data }", 4 )
                    ProcessData( "${ data.DNI  }", Json )
                    break
                case "SwitchLight":
                    Logging( "SwitchLight for ${ data.DNI }: ${ resp.data }", 4 )
                    ProcessData( "${ data.DNI  }", Json )
                    break
                case "LocateBridge":
                    Logging( "LocateBridge for ${ data.DNI }: ${ resp.data }", 4 )
                    ProcessData( "${ data.DNI  }", Json )
                    break
                case "LocateCamera":
                    Logging( "LocateCamera for ${ data.DNI }: ${ resp.data }", 4 )
                    ProcessData( "${ data.DNI  }", Json )
                    break
                case "LocateDoorbell":
                    Logging( "LocateDoorbell for ${ data.DNI }: ${ resp.data }", 4 )
                    ProcessData( "${ data.DNI  }", Json )
                    break
                case "LocateLight":
                    Logging( "LocateLight for ${ data.DNI }: ${ resp.data }", 4 )
                    ProcessData( "${ data.DNI  }", Json )
                    break
                case "LocateSensor":
                    Logging( "LocateSensor for ${ data.DNI }: ${ resp.data }", 4 )
                    ProcessData( "${ data.DNI  }", Json )
                    break
                case "LightBrightness":
                    Logging( "LightBrightness for ${ data.DNI }: ${ resp.data }", 4 )
                    ProcessData( "${ data.DNI  }", Json )
                    break
                case "MoveCameraXY":
                    Logging( "MoveCameraXY for ${ data.DNI }: ${ resp.data }", 4 )
                    break
                case "ZoomCamera":
                    Logging( "ZoomCamera for ${ data.DNI }: ${ resp.data }", 4 )
                    break
                case "StopCamera":
                    Logging( "StopCamera for ${ data.DNI }: ${ resp.data }", 4 )
                    break
                case "GoToPreset":
                    Logging( "GoToPreset for ${ data.DNI }: ${ resp.data }", 4 )
                    break
                case "SetRecordingStatus":
                	Logging( "SetRecordingStatus for ${ data.DNI }: ${ resp.data }", 4 )
                	ProcessData( "${ data.DNI  }", Json )
                	break
                case "SetStreamingStatus":
                	Logging( "SetStreamingStatus for ${ data.DNI }: ${ resp.data }", 4 )
                	ProcessData( "${ data.DNI  }", Json )
                	break
                default:
                    Logging( "${ data.Method } Unhandled: ${ resp.data }", 3 )
                    break
            }
            break
        case 400: // Bad request
            ProcessEvent( "Status", "${ data.Method } Bad Request, maybe Login again or method is wrong..." )
            Logging( "Bad Request for ${ data.Method } maybe Login again or method is wrong...", 5 )
            break
        case 401: // Unauthorized
            if( state.LoginRetries < 5 ){
                ProcessEvent( "Status", "${ data.Method } Unauthorized, attempting login and retry..." )
                Logging( "Unauthorized for ${ data.Method }, attempting login and retry...", 5 )
                ProcessState( "LoginRetries", ( state.LoginRetries + 1 ) )
                Login( false )
                switch( data.Method ){
                    case "Bootstrap":
                        GetProtectInfo()
                        break
                    case "GetMotionEvents":
                        GetMotionEvents()
                        break
                    case "AuthKey":
                    case "GetChildStatus":
                    case "GetBridgeStatus":
                    case "GetCameraStatus":
                    case "GetDoorbellStatus":
                    case "GetLightStatus":
                    case "GetSensorStatus":
                    case "SendBridgeSettings":
                    case "SendCameraSettings":
                    case "SendDoorbellSettings":
                    case "SendLightSettings":
                    case "SendSensorSettings":
                    case "SwitchLight":
                    case "LocateBridge":
                    case "LocateCamera":
                    case "LocateDoorbell":
                    case "LocateLight":
                    case "LocateSensor":
                    case "LightBrightness":
                    default:
                        Logging( "${ data.Method } Unhandled: ${ resp.data }", 3 )
                        break
                }
            } else {
                ProcessEvent( "Status", "${ data.Method } Unauthorized, too many retry failures, try again manually." )
                Logging( "Unauthorized for ${ data.Method }, too many retry failures, try again manually.", 5 )
            }
			break
        case 404:
            ProcessEvent( "Status", "${ data.Method } Page not found error" )
            Logging( "Page not found for ${ data.Method }", 5 )
			break
        case 408:
            ProcessEvent( "Status", "Request timeout for ${ data.Method }" )
            Logging( "Timeout for ${ data.Method } headers = ${ resp.getHeaders() }", 4 )
			break
		default:
            ProcessEvent( "Status", "Error ${ resp.status } connecting for ${ data.Method }" )
			Logging( "Error connecting to Unifi Controller: ${ resp.status } for ${ data.Method }", 5 )
			break
	}
}

// Attempt to identify/locate a device
def LocateLight( String DNI, String ChildID ){
    def Attempt = "api/lights/${ ChildID }/locate"
    asynchttpPost( "ReceiveData", GenerateProtectParams( "${ Attempt }" ), [ Method: "LocateLight", DNI: "${ DNI }", ChildID: "${ ChildID }" ] )
}

// Attempt to identify/locate a device
def LocateCamera( String DNI, String ChildID ){
    def Attempt = "api/cameras/${ ChildID }/locate"
    asynchttpPost( "ReceiveData", GenerateProtectParams( "${ Attempt }" ), [ Method: "LocateCamera", DNI: "${ DNI }", ChildID: "${ ChildID }" ] )
}

// Attempt to identify/locate a device
def LocateDoorbell( String DNI, String ChildID ){
    def Attempt = "api/doorbells/${ ChildID }/locate"
    asynchttpPost( "ReceiveData", GenerateProtectParams( "${ Attempt }" ), [ Method: "LocateDoorbell", DNI: "${ DNI }", ChildID: "${ ChildID }" ] )
}

// Attempt to identify/locate a device
def LocateBridge( String DNI, String ChildID ){
    def Attempt = "api/bridges/${ ChildID }/locate"
    asynchttpPost( "ReceiveData", GenerateProtectParams( "${ Attempt }" ), [ Method: "LocateBridge", DNI: "${ DNI }", ChildID: "${ ChildID }" ] )
}

// Attempt to identify/locate a device
def LocateSensor( String DNI, String ChildID ){
    def Attempt = "api/sensors/${ ChildID }/locate"
    asynchttpPost( "ReceiveData", GenerateProtectParams( "${ Attempt }" ), [ Method: "LocateSensor", DNI: "${ DNI }", ChildID: "${ ChildID }" ] )
}

// Set Recording status for camera
def SetRecordingStatus( String DNI, String ChildID, Value ){
    def Attempt = "api/cameras"
    def SettingString
    if( Value == "Never" ){
        SettingString = "{\"recordingSettings\":{\"mode\":\"never\"}}"
    } else {
        SettingString = "{\"recordingSettings\":{\"mode\":\"always\"}}"
    }
    asynchttpPatch( "ReceiveData", GenerateProtectCommandParams( "${ Attempt }", "${ ChildID }", SettingString ), [ Method: "SetRecordingStatus", DNI: "${ DNI }", ChildID: "${ ChildID }", Value: "${ Value }" ] )
}

// Set Streaming status for camera
def SetStreamingStatus( String DNI, String ChildID, String Stream, String Value, Channels ){
    def Attempt = "api/cameras"
    def StreamNum
    if( Stream == "High" ){
        StreamNum = 0
    } else if( Stream == "Medium" ){
        StreamNum = 1
    } else {
        StreamNum = 2
    }
    def TempChannels = "{\"channels\":[{"
    if( Value == "Enabled" ){
        Channels[ StreamNum ].isRtspEnabled = true
    } else {
        Channels[ StreamNum ].isRtspEnabled = false
    }
    Channels[ 0 ].each(){
        TempChannels += "\"${ it.key }\":"
        if( ( it.value == true ) || ( it.value == false ) || ( it.value == null ) || ( it.key == "fpsValues" ) ){
            TempChannels += "${ it.value },"
        } else {
            def TempValue = "${ it.value }"
            try{
                int TempInt = Integer.parseInt( TempValue )
                TempChannels += "${ TempInt },"
            } catch( NumberFormatException e ){
                TempChannels += "\"${ it.value }\","
            }
        }
	}
    TempChannels = TempChannels.substring( 0, TempChannels.length() - 1 )
    TempChannels += "},{"
   	Channels[ 1 ].each(){
        TempChannels += "\"${ it.key }\":"
        if( ( it.value == true ) || ( it.value == false ) || ( it.value == null ) || ( it.key == "fpsValues" ) ){
            TempChannels += "${ it.value },"
        } else {
            def TempValue = "${ it.value }"
            try{
                int TempInt = Integer.parseInt( TempValue )
                TempChannels += "${ TempInt },"
            } catch( NumberFormatException e ){
                TempChannels += "\"${ it.value }\","
            }
        }
	}
    TempChannels = TempChannels.substring( 0, TempChannels.length() - 1 )
    TempChannels += "},{"
    Channels[ 2 ].each(){
        TempChannels += "\"${ it.key }\":"
        if( ( it.value == true ) || ( it.value == false ) || ( it.value == null ) || ( it.key == "fpsValues" ) ){
            TempChannels += "${ it.value },"
        } else {
            def TempValue = "${ it.value }"
            try{
                int TempInt = Integer.parseInt( TempValue )
                TempChannels += "${ TempInt },"
            } catch( NumberFormatException e ){
                TempChannels += "\"${ it.value }\","
            }
        }
	}
    TempChannels = TempChannels.substring( 0, TempChannels.length() - 1 )
    TempChannels += "}]}"
    asynchttpPatch( "ReceiveData", GenerateProtectCommandParams( "${ Attempt }", "${ ChildID }", TempChannels ), [ Method: "SetStreamingStatus", DNI: "${ DNI }", ChildID: "${ ChildID }", Value: "${ Channels }" ] )
}

// Attempt to stop a PTZ camera from moving
def StopCamera( String DNI, String ChildID ){
    def Attempt = "api/cameras/${ ChildID }/move"
    def StopString = "{\"type\":\"continuous\",\"payload\":{\"x\":0,\"y\":0,\"z\":0}}"
    asynchttpPost( "ReceiveData", GenerateProtectPTZCameraParams( "${ Attempt }", "${ StopString }" ), [ Method: "StopCamera", DNI: "${ DNI }", ChildID: "${ ChildID }" ] )
}
def StopCamera( Map data ){
    if( data.ChildID == null ){
        data.ChildID = getChildDevice( "${ data.Device }" ).ReturnState( "ID" )
    }
    def Attempt = "api/cameras/${ data.ChildID }/move"
    def StopString = "{\"type\":\"continuous\",\"payload\":{\"x\":0,\"y\":0,\"z\":0}}"
    asynchttpPost( "ReceiveData", GenerateProtectPTZCameraParams( "${ Attempt }", "${ StopString }" ), [ Method: "StopCamera", DNI: "${ data.DNI }", ChildID: "${ data.ChildID }" ] )
}


// Attempt to move a PTZ camera
def MoveCameraXY( String DNI, String ChildID, X = 0, Y = 0 ){
    def Attempt = "api/cameras/${ ChildID }/move"
    def TempX = 0
    def TempY = 0
    def Delay = 0
    if( X > 0 ){
        TempX = 750
        Delay = ( X * 1000 )
    } else if( X < 0 ){
        TempX = -750
        Delay = ( X * -1000 )
    }
    if( Y > 0 ){
        TempY = 750
        Delay = ( Y * 1000 )
    } else if( Y < 0 ){
        TempY = -750
        Delay = ( Y * -1000 )
    }
    if( Delay < 100 ){
        Delay = 500
    }
    def MoveString = "{\"type\":\"continuous\",\"payload\":{\"x\":${ TempX as int },\"y\":${ TempY as int }}}"
    Logging( "MoveCameraXY ${ MoveString }", 4 )
    asynchttpPost( "ReceiveData", GenerateProtectPTZCameraParams( "${ Attempt }", "${ MoveString }" ), [ Method: "MoveCameraXY", DNI: "${ DNI }", ChildID: "${ ChildID }", X: ( TempX as int ), Y: ( TempY as int ) ] )
    runInMillis( Delay as int, "StopCamera", [ data: [ DNI: "${ DNI }", ChildID: "${ ChildID }" ] ] )
}

// Attempt to zoom in/out a PTZ camera
def ZoomCamera( String DNI, String ChildID, Z = 0 ){
    def Attempt = "api/cameras/${ ChildID }/move"
    def TempZ = 0
    def Delay = 0
    if( Z > 0 ){
        TempZ = 750
        Delay = Z
    } else if( Z < 0 ){
        TempZ = -750
        Delay = ( Z * -1 )
    }
    def ZoomString = "{\"type\":\"continuous\",\"payload\":{\"x\":0,\"y\":0,\"z\":${ TempZ as int }}}"
    Logging( "ZoomCamera ${ ZoomString }", 4 )
    asynchttpPost( "ReceiveData", GenerateProtectPTZCameraParams( "${ Attempt }", "${ ZoomString }" ), [ Method: "ZoomCamera", DNI: "${ DNI }", ChildID: "${ ChildID }", Z: ( TempZ as int ) ] )
    runInMillis( Delay as int, "StopCamera", [ data: [ DNI: "${ DNI }", ChildID: "${ ChildID }" ] ] )
}

// Attempt to send camera to it's home position
def HomeCamera( String DNI, String ChildID ){
    GoToPreset( DNI, ChildID, "0" )
}

// Attempt to send camera to a preset position, defaults to Home position
def GoToPreset( String DNI, String ChildID, String PresetInput = "0" ){
    def Preset = ( ( PresetInput as int ) - 1 ) // Presets are handled in typical array fashion starting at 0 plus home position is at -1
    def Attempt = "api/cameras/${ ChildID }/ptz/goto/${ Preset }"
    asynchttpPost( "ReceiveData", GenerateProtectPTZCameraParams( "${ Attempt }" ), [ Method: "GoToPreset", DNI: "${ DNI }", ChildID: "${ ChildID }", Preset: "${ Preset }" ] )
}

// Configure device settings based on Preferences
def SendBridgeSettings( String DNI, String ChildID, String Value ){
    def Attempt = "api/bridges"
    asynchttpPatch( "ReceiveData", GenerateProtectManageParams( "${ Attempt }", "${ ChildID }", "${ Value }" ), [ Method: "SendBridgeSettings", DNI: "${ DNI }", ChildID: "${ ChildID }", Value: "${ Value }" ] )
}

// Configure device settings based on Preferences
def SendLightSettings( String DNI, String ChildID, String Value ){
    def Attempt = "api/lights"
    asynchttpPatch( "ReceiveData", GenerateProtectManageParams( "${ Attempt }", "${ ChildID }", "${ Value }" ), [ Method: "SendLightSettings", DNI: "${ DNI }", ChildID: "${ ChildID }", Value: "${ Value }" ] )
}

// Configure device settings based on Preferences
def SendSensorSettings( String DNI, String ChildID, String Value ){
    def Attempt = "api/sensors"
    asynchttpPatch( "ReceiveData", GenerateProtectManageParams( "${ Attempt }", "${ ChildID }", "${ Value }" ), [ Method: "SendSensorSettings", DNI: "${ DNI }", ChildID: "${ ChildID }", Value: "${ Value }" ] )
}

// Configure device settings based on Preferences
def SendCameraSettings( String DNI, String ChildID, String Value ){
    def Attempt = "api/cameras"
    asynchttpPatch( "ReceiveData", GenerateProtectManageParams( "${ Attempt }", "${ ChildID }", "${ Value }" ), [ Method: "SendCameraSettings", DNI: "${ DNI }", ChildID: "${ ChildID }", Value: "${ Value }" ] )
}

// Configure device settings based on Preferences
def SendDoorbellSettings( String DNI, String ChildID, String Value ){
    def Attempt = "api/cameras"
    asynchttpPatch( "ReceiveData", GenerateProtectManageParams( "${ Attempt }", "${ ChildID }", "${ Value }" ), [ Method: "SendDoorbellSettings", DNI: "${ DNI }", ChildID: "${ ChildID }", Value: "${ Value }" ] )
}

// Send a notification to the doorbell
def DoorbellNotification( String DNI, String ChildID, String Value ){
    def Attempt = "api/cameras"
    def Params = GenerateProtectManageParams( "${ Attempt }", "${ ChildID }", "${ Value }" )
    asynchttpPatch( "ReceiveData", Params, [ Method: "DoorbellNotification", DNI: "${ DNI }", ChildID: "${ ChildID }", Value: "${ Value }" ] )
}

// Handle switching light on or off
def SwitchLight( String DNI, String ChildID, String Value ){
    def Attempt = "api/lights"
    if( Value == "on" ){
        asynchttpPatch( "ReceiveData", GenerateProtectCommandParams( "${ Attempt }", "${ ChildID }", "{\"lightOnSettings\":{\"isLedForceOn\":true}}" ), [ Method: "SwitchLight", DNI: "${ DNI }", ChildID: "${ ChildID }", Value: "${ Value }" ] )
    } else {
        asynchttpPatch( "ReceiveData", GenerateProtectCommandParams( "${ Attempt }", "${ ChildID }", "{\"lightOnSettings\":{\"isLedForceOn\":false}}" ), [ Method: "SwitchLight", DNI: "${ DNI }", ChildID: "${ ChildID }", Value: "${ Value }" ] )
    }
}

// Handle switching light level
def LightBrightness( String DNI, String ChildID, Value ){
    def Attempt = "api/lights"
    asynchttpPatch( "ReceiveData", GenerateProtectCommandParams( "${ Attempt }", "${ ChildID }", "{\"lightDeviceSettings\":{\"ledLevel\":${ Value }}}" ), [ Method: "LightBrightness", DNI: "${ DNI }", ChildID: "${ ChildID }", Value: "${ Value }" ] )
}

// Get a specific child's status
def GetBridgeStatus( String DNI, String ChildID ){
    def Attempt = "api/bridges/${ ChildID }"
    asynchttpGet( "ReceiveData", GenerateProtectParams( "${ Attempt }" ), [ Method: "GetBridgeStatus", DNI: "${ DNI }", ChildID: "${ ChildID }" ] )
}

// Get a specific child's status
def GetCameraStatus( String DNI, String ChildID ){
    def Attempt = "api/cameras/${ ChildID }"
    asynchttpGet( "ReceiveData", GenerateProtectParams( "${ Attempt }" ), [ Method: "GetCameraStatus", DNI: "${ DNI }", ChildID: "${ ChildID }" ] )
}

// Get a specific child's status
def GetDoorbellStatus( String DNI, String ChildID ){
    def Attempt = "api/doorbells/${ ChildID }"
    asynchttpGet( "ReceiveData", GenerateProtectParams( "${ Attempt }" ), [ Method: "GetDoorbellStatus", DNI: "${ DNI }", ChildID: "${ ChildID }" ] )
}

// Get a specific child's status
def GetLightStatus( String DNI, String ChildID ){
    def Attempt = "api/lights/${ ChildID }"
    asynchttpGet( "ReceiveData", GenerateProtectParams( "${ Attempt }" ), [ Method: "GetLightStatus", DNI: "${ DNI }", ChildID: "${ ChildID }" ] )
}

// Get a specific child sensor's status
def GetSensorStatus( Map data ){
    if( data.ChildID == null ){
        data.ChildID = getChildDevice( "${ data.Device }" ).ReturnState( "ID" )
    }
    GetSensorStatus( data.Device, data.ChildID )
}

// Get a specific child sensor's status
def GetSensorStatus( String DNI, String ChildID ){
    if( DNI.split( " " )[ 0 ] == "Sensor" ){
    	def Attempt = "api/sensors/${ ChildID }"
    	asynchttpGet( "ReceiveData", GenerateProtectParams( "${ Attempt }" ), [ Method: "GetSensorStatus", DNI: "${ DNI }", ChildID: "${ ChildID }" ] )
    }
}

// Reboot the controller
def Reboot( String Confirmation ){
    if( Confirmation == "Reboot" ){
        def Params
        if( Controller == "Unifi Dream Machine (inc Pro)" ){
            Params = [ uri: "https://${ UnifiURL }:443/api/system/reboot", ignoreSSLIssues: true, headers: [ Referer: "https://${ UnifiURL }/settings/advanced", Host: "${ UnifiURL }", Origin: "https://${ UnifiURL }", Accept: "*/*", Cookie: "${ state.Cookie }", "X-CSRF-Token": "${ state.CSRF }" ] ]
        } else {
            Params = [ uri: "https://${ UnifiURL }:${ ControllerPort }/api/system/reboot", ignoreSSLIssues: true, headers: [ Referer: "https://${ UnifiURL }/settings/advanced", Host: "${ UnifiURL }", Origin: "https://${ UnifiURL }", Accept: "*/*", Cookie: "${ state.Cookie }", "X-CSRF-Token": "${ state.CSRF }" ] ]
        }
        Logging( "Reboot Params = ${ Params }", 4 )
        try{
            httpPost( Params ){ resp ->
                switch( resp.getStatus() ){
                    case 200:
                    case 204:
                        ProcessEvent( "Status", "Reboot command sent" )
                        Logging( "Reboot command sent = ${ resp.data }", 4 )
                        break
                    default:
                        Logging( "Reboot command error ${ resp.getStatus() }", 5 )
                        break
                }
            }
        } catch( Exception e ){
            Logging( "Reboot failed due to ${ e }", 5 )
        }
    } else {
        Logging( "Reboot confirmation incorrect. Reboot command ignored.", 5 )
        ProcessEvent( "Status", "Reboot confirmation incorrect. Reboot command ignored." )
    }
}

// Power down the controller
def PowerDown( String Confirmation ){
    if( Confirmation == "PowerDown" ){
        def Params
        if( Controller == "Unifi Dream Machine (inc Pro)" ){
            Params = [ uri: "https://${ UnifiURL }:443/api/system/poweroff", ignoreSSLIssues: true, headers: [ Referer: "https://${ UnifiURL }/settings/advanced", Host: "${ UnifiURL }", Origin: "https://${ UnifiURL }", Accept: "*/*", Cookie: "${ state.Cookie }", "X-CSRF-Token": "${ state.CSRF }" ] ]
        } else {
            Params = [ uri: "https://${ UnifiURL }:${ ControllerPort }/api/system/poweroff", ignoreSSLIssues: true, headers: [ Referer: "https://${ UnifiURL }/settings/advanced", Host: "${ UnifiURL }", Origin: "https://${ UnifiURL }", Accept: "*/*", Cookie: "${ state.Cookie }", "X-CSRF-Token": "${ state.CSRF }" ] ]
        }
        Logging( "PowerDown Params = ${ Params }", 4 )
        try{
            httpPost( Params ){ resp ->
                switch( resp.getStatus() ){
                    case 200:
                    case 204:
                        ProcessEvent( "Status", "PowerDown command sent" )
                        Logging( "PowerDown command sent = ${ resp.data }", 4 )
                        break
                    default:
                        Logging( "PowerDown command error ${ resp.getStatus() }", 5 )
                        break
                }
            }
        } catch( Exception e ){
            Logging( "PowerDown failed due to ${ e }", 5 )
        }
    } else {
        Logging( "PowerDown confirmation incorrect. PowerDown command ignored.", 5 )
        ProcessEvent( "Status", "PowerDown confirmation incorrect. PowerDown command ignored." )
    }
}

// Generate Protect Params assembles the parameters to be sent to the controller rather than repeat so much of it
def GenerateProtectParams( String Path, String Data = null ){
	def Params
	if( Controller == "Unifi Dream Machine (inc Pro)" ){
        if( Data != null ){
            Params = [ uri: "https://${ UnifiURL }/proxy/protect/${ Path }", ignoreSSLIssues: true, requestContentType: "application/json", contentType: "application/json", headers: [ Host: "${ UnifiURL }", Accept: "*/*", Cookie: "${ state.Cookie }", 'X-CSRF-Token': "${ state.CSRF }", 'accessKey': "${ state.AuthKey }" ], data:"${ Data }" ]
        } else {
            Params = [ uri: "https://${ UnifiURL }/proxy/protect/${ Path }", ignoreSSLIssues: true, requestContentType: "application/json", contentType: "application/json", headers: [ Host: "${ UnifiURL }", Accept: "*/*", Cookie: "${ state.Cookie }", 'X-CSRF-Token': "${ state.CSRF }", 'accessKey': "${ state.AuthKey }" ] ]
        }
	} else {
        if( Data != null ){
            Params = [ uri: "https://${ UnifiURL }:${ ControllerPort }/${ Path }", ignoreSSLIssues: true, requestContentType: "application/json", contentType: "application/json", headers: [ Host: "${ UnifiURL }", Accept: "*/*", Cookie: "${ state.Cookie }", 'X-CSRF-Token': "${ state.CSRF }", 'accessKey': "${ state.AuthKey }" ], data:"${ Data }" ]
        } else {
            Params = [ uri: "https://${ UnifiURL }:${ ControllerPort }/${ Path }", ignoreSSLIssues: true, requestContentType: "application/json", contentType: "application/json", headers: [ Host: "${ UnifiURL }", Accept: "*/*", Cookie: "${ state.Cookie }", 'X-CSRF-Token': "${ state.CSRF }", 'accessKey': "${ state.AuthKey }" ] ]
        }
	}
    Logging( "Parameters = ${ Params }", 4 )
	return Params
}

// Generate Protect PTZ Camera Params assembles the parameters to be sent to the controller rather than repeat so much of it
def GenerateProtectPTZCameraParams( String Path, String Data = null ){
	def Params
	if( Controller == "Unifi Dream Machine (inc Pro)" ){
        if( Data != null ){
            Params = [ uri: "https://${ UnifiURL }/proxy/protect/${ Path }", ignoreSSLIssues: true, requestContentType: "application/json", contentType: "application/json", headers: [ Host: "${ UnifiURL }", Accept: "*/*", Cookie: "${ state.Cookie }", Origin: "https://${ UnifiURL }", 'X-Csrf-Token': "${ state.CSRF }" ], body:"${ Data }" ]
        } else {
            Params = [ uri: "https://${ UnifiURL }/proxy/protect/${ Path }", ignoreSSLIssues: true, requestContentType: "application/json", contentType: "application/json", headers: [ Host: "${ UnifiURL }", Accept: "*/*", Cookie: "${ state.Cookie }", Origin: "https://${ UnifiURL }", 'X-Csrf-Token': "${ state.CSRF }" ] ]
        }
	} else {
        if( Data != null ){
            Params = [ uri: "https://${ UnifiURL }:${ ControllerPort }/${ Path }", ignoreSSLIssues: true, requestContentType: "application/json", contentType: "application/json", headers: [ Host: "${ UnifiURL }", Accept: "*/*", Cookie: "${ state.Cookie }", Origin: "https://${ UnifiURL }", 'X-Csrf-Token': "${ state.CSRF }" ], body:"${ Data }" ]
        } else {
            Params = [ uri: "https://${ UnifiURL }:${ ControllerPort }/${ Path }", ignoreSSLIssues: true, requestContentType: "application/json", contentType: "application/json", headers: [ Host: "${ UnifiURL }", Accept: "*/*", Cookie: "${ state.Cookie }", Origin: "https://${ UnifiURL }", 'X-Csrf-Token': "${ state.CSRF }" ] ]
        }
	}
    Logging( "Parameters = ${ Params }", 4 )
	return Params
}

// Generate Protect Image Params assembles the parameters to be sent to the controller rather than repeat so much of it
def GenerateProtectImageParams( String Path, String Data = null ){
	def Params
	if( Controller == "Unifi Dream Machine (inc Pro)" ){
        if( Data != null ){
            Params = [ uri: "https://${ UnifiURL }/proxy/protect/${ Path }", ignoreSSLIssues: true, requestContentType: "application/octet-stream", headers: [ Host: "${ UnifiURL }", Accept: "*/*", Cookie: "${ state.Cookie }", 'X-CSRF-Token': "${ state.CSRF }", 'accessKey': "${ state.AuthKey }" ], data:"${ Data }" ]
        } else {
            Params = [ uri: "https://${ UnifiURL }/proxy/protect/${ Path }", ignoreSSLIssues: true, requestContentType: "application/octet-stream", headers: [ Host: "${ UnifiURL }", Accept: "*/*", Cookie: "${ state.Cookie }", 'X-CSRF-Token': "${ state.CSRF }", 'accessKey': "${ state.AuthKey }" ] ]
        }
	} else {
        if( Data != null ){
            Params = [ uri: "https://${ UnifiURL }:${ ControllerPort }/${ Path }", ignoreSSLIssues: true, requestContentType: "application/octet-stream", headers: [ Host: "${ UnifiURL }", Accept: "*/*", Cookie: "${ state.Cookie }", 'X-CSRF-Token': "${ state.CSRF }", 'accessKey': "${ state.AuthKey }" ], data:"${ Data }" ]
        } else {
            Params = [ uri: "https://${ UnifiURL }:${ ControllerPort }/${ Path }", ignoreSSLIssues: true, requestContentType: "application/octet-stream", headers: [ Host: "${ UnifiURL }", Accept: "*/*", Cookie: "${ state.Cookie }", 'X-CSRF-Token': "${ state.CSRF }", 'accessKey': "${ state.AuthKey }" ] ]
        }
	}
    Logging( "Parameters = ${ Params }", 4 )
	return Params
}

// Generate Protect Params assembles the parameters to be sent to the controller rather than repeat so much of it
def GenerateProtectCommandParams( String Path, String ChildID, String Data = null ){
	def Params
	if( Controller == "Unifi Dream Machine (inc Pro)" ){
        if( Data != null ){
            Params = [ uri: "https://${ UnifiURL }/proxy/protect/${ Path }/${ ChildID }", ignoreSSLIssues: true, requestContentType: "application/json", contentType: "application/json", headers: [ Referer: "https://${ UnifiURL }/protect/devices/${ ChildID }/general", Origin: "https://${ UnifiURL }", Cookie: "${ state.Cookie }", 'X-CSRF-Token': "${ state.CSRF }" ], body:"${ Data }" ]
        } else {
            Params = [ uri: "https://${ UnifiURL }/proxy/protect/${ Path }/${ ChildID }", ignoreSSLIssues: true, requestContentType: "application/json", contentType: "application/json", headers: [ Referer: "https://${ UnifiURL }/protect/devices/${ ChildID }/general", Origin: "https://${ UnifiURL }", Cookie: "${ state.Cookie }", 'X-CSRF-Token': "${ state.CSRF }" ] ]
        }
	} else {
        if( Data != null ){
            Params = [ uri: "https://${ UnifiURL }:${ ControllerPort }/${ Path }/${ ChildID }", ignoreSSLIssues: true, requestContentType: "application/json", contentType: "application/json", headers: [ Host: "${ UnifiURL }:${ ControllerPort }", Accept: "*/*", Cookie: "${ state.Cookie }", 'X-CSRF-Token': "${ state.CSRF }", 'accessKey': "${ state.AuthKey }" ], body:"${ Data }" ]
        } else {
            Params = [ uri: "https://${ UnifiURL }:${ ControllerPort }/${ Path }/${ ChildID }", ignoreSSLIssues: true, requestContentType: "application/json", contentType: "application/json", headers: [ Host: "${ UnifiURL }:${ ControllerPort }", Accept: "*/*", Cookie: "${ state.Cookie }", 'X-CSRF-Token': "${ state.CSRF }", 'accessKey': "${ state.AuthKey }" ] ]
        }
	}
    Logging( "Parameters = ${ Params }", 4 )
	return Params
}

// Generate Protect Params assembles the parameters to be sent to the controller rather than repeat so much of it
def GenerateProtectManageParams( String Path, String ChildID, String Data ){
	def Params
	if( Controller == "Unifi Dream Machine (inc Pro)" ){
        if( Data != null ){
            Params = [ uri: "https://${ UnifiURL }/proxy/protect/${ Path }/${ ChildID }", ignoreSSLIssues: true, requestContentType: "application/json", contentType: "application/json", headers: [ Referer: "https://${ UnifiURL }/protect/devices/${ ChildID }/manage", Origin: "https://${ UnifiURL }", Cookie: "${ state.Cookie }", 'X-CSRF-Token': "${ state.CSRF }" ], body:"${ Data }" ]
        } else {
            Params = [ uri: "https://${ UnifiURL }/proxy/protect/${ Path }/${ ChildID }", ignoreSSLIssues: true, requestContentType: "application/json", contentType: "application/json", headers: [ Referer: "https://${ UnifiURL }/protect/devices/${ ChildID }/manage", Origin: "https://${ UnifiURL }", Cookie: "${ state.Cookie }", 'X-CSRF-Token': "${ state.CSRF }" ] ]
        }
	}
    Logging( "Parameters = ${ Params }", 4 )
	return Params
}

// Process data coming in for a device
def ProcessData( String Device, data ){
    //Logging( "${ Device } Data: ${ data }", 3 )
    data.each(){
        if( it.key != null ){
            def SensorType
            if( getChildDevice( "${ Device }" ) != null ){
                if( getChildDevice( "${ Device }" ).ReturnState( "SensorType" ) != null ){
            		SensorType = getChildDevice( "${ Device }" ).ReturnState( "SensorType" )
                }
            }
            switch( it.key ){
                case "mac":
//					PostStateToChild( "${ Device }", "MAC", it.value )
					break
                case "type":
//					PostStateToChild( "${ Device }", "Type", it.value )
                	if( Device.split( " " )[ 0 ] == "Sensor" ){
                		switch( it.value ){
                            case "USL-Motion-US":
                                SetChildParameter( "${ Device }", "SensorType", "USL Motion" )
                            	PostStateToChild( "${ Device }", "SensorType", "USL Motion" )
                            	SensorType = "USL Motion"
                                break
                            case "USL-Entry-US":
                                SetChildParameter( "${ Device }", "SensorType", "USL Entry" )
                            	PostStateToChild( "${ Device }", "SensorType", "USL Entry" )
                            	SensorType = "USL Entry"
                                break
                            case "USL-Environmental-US":
                                SetChildParameter( "${ Device }", "SensorType", "USL Environmental" )
                            	PostStateToChild( "${ Device }", "SensorType", "USL Environmental" )
                            	SensorType = "USL Environmental"
                                break
                            case "UFP-SENSE":
                                SetChildParameter( "${ Device }", "SensorType", "UP Sense" )
                            	PostStateToChild( "${ Device }", "SensorType", "UP Sense" )
                            	SensorType = "UP Sense"
                                break
                            default:
                                Logging( "No specific handling for ${ Device } Type = ${ it.value }", 3 )
                                break
                        }
                    }
					break
                case "id":
                    PostStateToChild( "${ Device }", "ID", it.value )
                    break
                case "version":
//                    PostStateToChild( "${ Device }", "ProtectVersion", it.value )
                    break
                case "name":
                    if( it.value != null ){
//                        PostStateToChild( "${ Device }", "DeviceName", it.value )
                        if( getChildDevice( "${ Device }" ).label == null ){
                            getChildDevice( "${ Device }" ).label = it.value
                        }
                    }
                    break
                case "model":
//                    PostStateToChild( "${ Device }", "Model", it.value )
                    break
                case "isMotionDetected":
                	Logging( "isMotionDetected data for ${ Device } = ${ it.value }", 4 )
                    if( it.value ){
                        PostEventToChild( "${ Device }", "motion", "active" )
                        if( Device.split( " " )[ 0 ] == "Sensor" ){
                            def MotionDuration = getChildDevice( "${ Device }" ).ReturnState( "MotionDuration" )
                			def ChildID = getChildDevice( "${ Device }" ).ReturnState( "ID" )
                    		if( MotionDuration == null ){
                        		MotionDuration = 15
                            }
                        	if( ChildID != null ){
                        		runIn( MotionDuration, "GetSensorStatus", [ data: [ Device: "${ Device }", ChildID: "${ ChildID }" ] ] )
                        	}
                        }
                    } else {
                        PostEventToChild( "${ Device }", "motion", "inactive" )
                    }
                	break
                case "isPirMotionDetected":
                	Logging( "isPirMotionDetected data for ${ Device } = ${ it.value }", 4 )
                    if( it.value ){
                        PostEventToChild( "${ Device }", "motion", "active" )
                    } else {
                        PostEventToChild( "${ Device }", "motion", "inactive" )
                    }
                    break
                case "isLightOn":
                    if( it.value ){
                        PostEventToChild( "${ Device }", "switch", "on" )
                    } else {
                        PostEventToChild( "${ Device }", "switch", "off" )
                    }
                    break
                case "isDark":
					PostEventToChild( "${ Device }", "Dark", ConvertBoolean( it.value ) )
					break
				case "camera":
					if( it.value != null ){
//						PostStateToChild( "${ Device }", "CameraPaired", it.value )
					} else {
//						PostStateToChild( "${ Device }", "CameraPaired", "None" )
					}
					break
				case "lightDeviceSettings":
                	if( ( SensorType == "UP Sense" ) || ( SensorType == "USL Environmental" ) || ( SensorType == null ) ){
                        it.value.each(){
                            switch( it.key ){
                                case "ledLevel":
                                    PostEventToChild( "${ Device }", "Brightness", it.value )
                                    switch( it.value ){
                                        case 1:
                                            PostEventToChild( "${ Device }", "level", 10, "%" )
                                            break
                                        case 2:
                                            PostEventToChild( "${ Device }", "level", 20, "%" )
                                            break
                                        case 3:
                                            PostEventToChild( "${ Device }", "level", 40, "%" )
                                            break
                                        case 4:
                                            PostEventToChild( "${ Device }", "level", 60, "%" )
                                            break
                                        case 5:
                                            PostEventToChild( "${ Device }", "level", 80, "%" )
                                            break
                                        case 6:
                                            PostEventToChild( "${ Device }", "level", 100, "%" )
                                            break
                                    }
                                    break
                                case "pirSensitivity":
//                                    PostStateToChild( "${ Device }", "MotionSensitivity", it.value )
                                    break
                                case "pirDuration":
                                    PostStateToChild( "${ Device }", "MotionDuration", ( it.value / 1000 ) )
                                    break
                                case "luxSensitivity":
//                                    PostStateToChild( "${ Device }", "LuxSensitivity", it.value )
                                    break
                                case "isIndicatorEnabled":
//                                    PostStateToChild( "${ Device }", "IndicatorEnabled", it.value )
                                    break
                                default:
                                    Logging( "Unhandled lightDeviceSettings for light ${ it.key } = ${ it.value }", 3 )
                                    break
                            }
                        }
                    }
                    break
				case "lightModeSettings":
                    if( ( SensorType == "UP Sense" ) || ( SensorType == "USL Environmental" ) || ( SensorType == null ) ){
                        it.value.each(){
                            switch( it.key ){
                                case "mode":
//                                    PostStateToChild( "${ Device }", "LightTrigger", it.value )
                                    break
                                case "enableAt":
//                                    PostStateToChild( "${ Device }", "TriggerAt", it.value )
                                    break
                                default:
                                    Logging( "Unhandled lightModeSetting for light ${ it.key } = ${ it.value }", 3 )
                                    break
                            }
                        }
                    }
					break
				case "state":
					PostEventToChild( "${ Device }", "DeviceStatus", it.value )
					break
				case "isConnected":
					if( it.value ){
//						PostStateToChild( "${ Device }", "presence", "present" )
					} else {
//						PostStateToChild( "${ Device }", "presence", "not present" )
					}
					break
				case "latestFirmwareVersion":
//					PostStateToChild( "${ Device }", "LatestFirmwareVersion", it.value )
					break
                case "firmwareVersion":
//					PostStateToChild( "${ Device }", "FirmwareVersion", it.value )
					break
                case "hardwareRevision":
//					PostStateToChild( "${ Device }", "HardwareRevision", it.value )
					break
				case "uptime":
                    if( it.value != null ){
					    def TempUptime = it.value as int
                        if( TempUptime >= 99999999 ){
                            TempUptime = ( ( TempUptime / 1000 ) as int )
                        }
					    def TempUptimeDays = Math.round( TempUptime / 86400 )
					    def TempUptimeHours = Math.round( ( TempUptime % 86400 ) / 3600 )
					    def TempUptimeMinutes = Math.round( ( TempUptime % 3600 ) / 60 )
					    def TempUptimeString = "${ TempUptimeDays } Day"
					    if( TempUptimeDays != 1 ){
					    	TempUptimeString += "s"
					    }
					    TempUptimeString += " ${ TempUptimeHours } Hour"
					    if( TempUptimeHours != 1 ){
					    	TempUptimeString += "s"
					    }
					    TempUptimeString += " ${ TempUptimeMinutes } Minute"
					    if( TempUptimeMinutes != 1 ){
					    	TempUptimeString += "s"
					    }
//                        PostStateToChild( "${ Device }", "Uptime", TempUptimeString )
                    }
					break
				case "platform":
//					PostStateToChild( "${ Device }", "Platform", it.value )
					break
                case "systemInfo":
                    it.value.each(){
						switch( it.key ){
							case "cpu":
								it.value.each(){
						            switch( it.key ){
                                        case "temperature":
                                            PostEventToChild( "${ Device }", "CPU_Temp", ConvertTemperature( "C", it.value ), "°${ location.getTemperatureScale() }" )
                                            break
                                        case "averageLoad":
                                            PostEventToChild( "${ Device }", "CPU_AverageLoad", it.value, "%" )
                                            break
                                    }
                                }
                                break
							case "memory":
                            	if( ( it.value.total != null ) && ( it.value.available != null ) ){
                                	PostEventToChild( "${ Device }", "MemoryAvailable", ( Math.round( ( it.value.available / it.value.total ) * 10000 ) / 100 ), "%" )
                                }
                                break
                            case "storage":
                            	if( ( it.value.size != null ) && ( it.value.available != null ) ){
                                	PostEventToChild( "${ Device }", "StorageAvailable", ( Math.round( ( it.value.available / it.value.size ) * 10000 ) / 100 ), "%" )
                                }
                                break
                        }
                    }
                    break
                case "batteryStatus":
					PostEventToChild( "${ Device }", "battery", it.value.percentage, "%" )
					break
                case "stats":
                    it.value.each{
                        switch( it.key ){
                            case "light":
                                PostEventToChild( "${ Device }", "illuminance", it.value.value )
                                PostEventToChild( "${ Device }", "LightAlert", it.value.status )
                                break
                            case "temperature":
                                PostEventToChild( "${ Device }", "temperature", ConvertTemperature( "C", it.value.value ), "°${ location.getTemperatureScale() }" )
                                PostEventToChild( "${ Device }", "TemperatureAlert", it.value.status )
                                break
                            case "humidity":
                                PostEventToChild( "${ Device }", "humidity", it.value.value )
                                PostEventToChild( "${ Device }", "HumidityAlert", it.value.status )
                                break
                        }
                    }
                    break
                case "bluetoothConnectionState":
                    it.value.each{
                        switch( it.key ){
                            case "signalQuality":
//                                PostStateToChild( "${ Device }", "lqi", it.value )
                                break
                            case "signalStrength":
//                                PostStateToChild( "${ Device }", "rssi", it.value )
                                break
                        }
                    }
                    break
                case "alarmTriggeredAt":
//                    PostStateToChild( "${ Device }", "Alarm_Triggered", ConvertEpochToDate( "${ it.value }" ) )
                    break
                case "openStatusChangedAt":
//                    PostStateToChild( "${ Device }", "Open_Status_Changed", ConvertEpochToDate( "${ it.value }" ) )
                    break
                case "tamperingDetectedAt":
//                    PostStateToChild( "${ Device }", "Tampering_Detected", ConvertEpochToDate( "${ it.value }" ) )
                    break
                case "leakDetectedAt":
                	if( ( SensorType == "UP Sense" ) || ( SensorType == "USL Environmental" ) || ( SensorType == null ) ){
//                    	PostStateToChild( "${ Device }", "Leak_Detected", ConvertEpochToDate( "${ it.value }" ) )
                    }
                    break
                case "motionDetectedAt":
                    if( ( SensorType != "USL Entry" ) || ( SensorType == null ) ){
                        if( it.value != null ){
                            Logging( "${ Device } Last Detected Motion At = ${ ConvertEpochToDate( "${ it.value }" ) }", 4 )
//                            PostStateToChild( "${ Device }", "Motion_Detected_At", ConvertEpochToDate( "${ it.value }" ) )
                        }
                    }
                    break
                case "lastDisconnect":
//                    PostStateToChild( "${ Device }", "Last_Disconnect", ConvertEpochToDate( "${ it.value }" ) )
                    break
                case "fwUpdateState":
                    switch( it.value ){
                        case "upToDate":
//                            PostStateToChild( "${ Device }", "FirmwareUpdateState", "Up To Date" )
                            break
                        default:
//                            PostStateToChild( "${ Device }", "FirmwareUpdateState", it.value )
                            break
                    }
                    break
                case "alarmSettings":
                    it.value.each{
                        switch( it.key ){
                            case "isEnabled":
                                PostEventToChild( "${ Device }", "Alarm_Enabled", ConvertBoolean( it.value ) )
                                break
                            default:
                            	if( getChildDevice( "${ Device }" ).ReturnState( "Alarm_Enabled" ) == "true" ){
//                                	PostStateToChild( "${ Device }", it.key, it.value )
                                }
                                break
                        }
                    }
                    break
                case "motionSettings":
                	if( ( SensorType != "USL Entry" ) || ( SensorType == null ) ){
                    	it.value.each{
                            switch( it.key ){
                                case "isEnabled":
                                    PostStateToChild( "${ Device }", "Motion_Enabled", ConvertBoolean( it.value ) )
                                    break
                                case "sensitivity":
                                    if( getChildDevice( "${ Device }" ).ReturnState( "Motion_Enabled" ) == "true" ){
                                        PostStateToChild( "${ Device }", "Motion_Sensitivity", it.value )
                                    }
                                    break
                                default:
                                    if( getChildDevice( "${ Device }" ).ReturnState( "Motion_Enabled" ) == "true" ){
                                        PostStateToChild( "${ Device }", it.key, it.value )
                                    }
                                    break
                            }
                        }
                    }
                    break
                case "temperatureSettings":
                    if( ( SensorType == "UP Sense" ) || ( SensorType == "USL Environmental" ) || ( SensorType == null ) ){
                        it.value.each{
                            switch( it.key ){
                                case "isEnabled":
                                    PostStateToChild( "${ Device }", "Temperature_Enabled", ConvertBoolean( it.value ) )
                                    break
                                case "margin":
                                    if( getChildDevice( "${ Device }" ).ReturnState( "Temperature_Enabled" ) == "true" ){
                                        PostStateToChild( "${ Device }", "Temperature_Margin", it.value )
                                    }
                                    break
                                case "lowThreshold":
                                    if( getChildDevice( "${ Device }" ).ReturnState( "Temperature_Enabled" ) == "true" ){
                                        PostStateToChild( "${ Device }", "Temperature_Low_Threshold", it.value )
                                    }
                                    break
                                case "highThreshold":
                                    if( getChildDevice( "${ Device }" ).ReturnState( "Temperature_Enabled" ) == "true" ){
                                        PostStateToChild( "${ Device }", "Temperature_High_Threshold", it.value )
                                    }
                                    break
                                default:
                                    if( getChildDevice( "${ Device }" ).ReturnState( "Temperature_Enabled" ) == "true" ){
                                        PostStateToChild( "${ Device }", it.key, it.value )
                                    }
                                    break
                            }
                        }
                    }
                    break
                case "humiditySettings":
                	if( ( SensorType == "UP Sense" ) || ( SensorType == "USL Environmental" ) || ( SensorType == null ) ){
                        it.value.each{
                            switch( it.key ){
                                case "isEnabled":
                                    PostStateToChild( "${ Device }", "Humidity_Enabled", ConvertBoolean( it.value ) )
                                    break
                                case "margin":
                                    if( getChildDevice( "${ Device }" ).ReturnState( "Humidity_Enabled" ) == "true" ){
                                        PostStateToChild( "${ Device }", "Humidity_Margin", it.value )
                                    }
                                    break
                                case "lowThreshold":
                                    if( getChildDevice( "${ Device }" ).ReturnState( "Humidity_Enabled" ) == "true" ){
                                        PostStateToChild( "${ Device }", "Humidity_Low_Threshold", it.value )
                                    }
                                    break
                                case "highThreshold":
                                    if( getChildDevice( "${ Device }" ).ReturnState( "Humidity_Enabled" ) == "true" ){
                                        PostStateToChild( "${ Device }", "Humidity_High_Threshold", it.value )
                                    }
                                    break
                                default:
                                    if( getChildDevice( "${ Device }" ).ReturnState( "Humidity_Enabled" ) == "true" ){
                                        PostStateToChild( "${ Device }", it.key, it.value )
                                    }
                                    break
                            }
                        }
                    }
                    break
                case "lightSettings":
                	if( ( SensorType == "UP Sense" ) || ( SensorType == "USL Environmental" ) || ( SensorType == null ) ){
                        it.value.each{
                            switch( it.key ){
                                case "isEnabled":
                                    PostStateToChild( "${ Device }", "Light_Enabled", ConvertBoolean( it.value ) )
                                    break
                                case "margin":
                                    if( getChildDevice( "${ Device }" ).ReturnState( "Light_Enabled" ) == "true" ){
                                        PostStateToChild( "${ Device }", "Light_Margin", it.value )
                                    }
                                    break
                                case "lowThreshold":
                                    if( getChildDevice( "${ Device }" ).ReturnState( "Light_Enabled" ) == "true" ){
                                        PostStateToChild( "${ Device }", "Light_Low_Threshold", it.value )
                                    }
                                    break
                                case "highThreshold":
                                    if( getChildDevice( "${ Device }" ).ReturnState( "Light_Enabled" ) == "true" ){
                                        PostStateToChild( "${ Device }", "Light_High_Threshold", it.value )
                                    }
                                    break
                                default:
                                    if( getChildDevice( "${ Device }" ).ReturnState( "Light_Enabled" ) == "true" ){
                                        PostStateToChild( "${ Device }", it.key, it.value )
                                    }
                                    break
                            }
                        }
                    }
                    break
                case "homekitSettings":
//                    PostStateToChild( "${ Device }", "Homekit_Settings", it.value )
                    break
                case "isOpened":
                    if( it.value ){
//                        PostEventToChild( "${ Device }", "contact", "open" )
                    } else {
//                        PostEventToChild( "${ Device }", "contact", "closed" )
                    }
                    break
                case "bridge":
//                    PostStateToChild( "${ Device }", "BridgeID", it.value )
                    break
                case "nvrMac":
//                    PostStateToChild( "${ Device }", "NVR_MAC", it.value )
                    break
                case "publicIp":
                case "wanIp":
//                    PostStateToChild( "${ Device }", "Public_IP", it.value )
                    break
                case "countryCode":
//                    PostStateToChild( "${ Device }", "Country_Code", it.value )
                    break
                case "corruptionState":
                    switch( it.value ){
                        case "healthy":
//                            PostStateToChild( "${ Device }", "Health_Status", "Healthy" )
                            break
                        default:
//                            PostStateToChild( "${ Device }", "Health_Status", it.value )
                            break
                    }
                    break
                case "isWaterproofCaseAttached":
//                    PostStateToChild( "${ Device }", "Waterproof_Case", ConvertBoolean( it.value ) )
                    break
                case "is4K":
//                    PostStateToChild( "${ Device }", "4K", ConvertBoolean( it.value ) )
                    break
                case "is2K":
//                    PostStateToChild( "${ Device }", "2K", ConvertBoolean( it.value ) )
                    break
                case "mountType":
                    switch( it.value ){
                        case "door":
                            PostStateToChild( "${ Device }", "MountType", "Door" )
                            break
                        case "window":
                            PostStateToChild( "${ Device }", "MountType", "Window" )
                            break
                        case "garage":
                            PostStateToChild( "${ Device }", "MountType", "Garage" )
                            break
                        case "leak":
                            PostStateToChild( "${ Device }", "MountType", "Leak" )
                            break
                        case "none":
                        case "null":
                        default:
                            PostStateToChild( "${ Device }", "MountType", "None" )
                            break
                    }
                    break
                case "recordingSchedulesV2":
//                    PostStateToChild( "${ Device }", "RecordingSchedules", it.value )
                    break
                case "hasRecordings":
//                    PostStateToChild( "${ Device }", "HasRecordings", it.value )
                    break
                case "uplinkDevice":
//                    PostStateToChild( "${ Device }", "UplinkDevice", it.value )
                    break
                case "deviceFirmwareSettings":
//                    PostStateToChild( "${ Device }", "FirmwareSettings", it.value )
                    break
                case "cameraCapacity":
//                    PostStateToChild( "${ Device }", "CameraCapacity", it.value )
                    break
                case "isNetworkInstalled":
//                    PostStateToChild( "${ Device }", "IsNetworkInstalled", it.value )
                    break
                case "isPtz":
//                	PostStateToChild( "${ Device }", "PanTiltZoom", ConvertBoolean( it.value ) )
                    break
                case "displayName":
//                    PostStateToChild( "${ Device }", "DisplayName", it.value )
                    break
                case "smartDetection":
//                    PostStateToChild( "${ Device }", "SmartDetection", it.value )
                    break
                case "currentResolution":
//                    PostStateToChild( "${ Device }", "CurrentResolution", it.value )
                    break
                case "alarms":
//                    PostEventToChild( "${ Device }", "Alarms", it.value )
                    break
                case "shortcuts":
//                    PostStateToChild( "${ Device }", "Shortcuts", it.value )
                    break
                case "tiltLimitsOfPrivacyZones":
//                    PostStateToChild( "${ Device }", "TiltLimitsOfPrivacyZones", it.value )
                    break
                case "videoCodec":
//                    PostStateToChild( "${ Device }", "VideoCodec", it.value )
                    break
                case "supportedScalingResolutions":
//                    PostStateToChild( "${ Device }", "SupportedScalingResolutions", it.value )
                    break
                case "clients":
//                    PostStateToChild( "${ Device }", "Clients", it.value )
                    break
                case "maxClients":
//                    PostStateToChild( "${ Device }", "MaxClients", it.value )
                    break
                case "isAccessInstalled":
//                    PostStateToChild( "${ Device }", "MaxClients", "${ it.value }" )
                    break
                // 3rd-party data
                case "isThirdPartyCamera":
//                    PostStateToChild( "${ Device }", "ThirdPartyCamera", "${ it.value }" )
                    break
                case "thirdPartyCameraInfo":
//                    PostStateToChild( "${ Device }", "ThirdPartyCameraInfo", "${ it.value }" )
                    break
                case "enableThirdPartyCamerasDiscovery":
//                    PostStateToChild( "${ Device }", "ThirdPartyCamerasEnabled", "${ it.value }" )
                    break
                case "extendedAiFeatures":
//                    PostStateToChild( "${ Device }", "ExtendedAIFeatures", "${ it.value }" )
                    break
                case "streamingChannels":
//                    PostStateToChild( "${ Device }", "StreamingChannels", "${ it.value }" )
                    break
                case "isAiReportingEnabled":
 //                   PostStateToChild( "${ Device }", "AiReportingEnabled", "${ it.value }" )
                    break
                case "fingerprintSettings":
 //                   PostStateToChild( "${ Device }", "FingerprintSettings", "${ it.value }" )
                    break
                case "nfcSettings":
 //                   PostStateToChild( "${ Device }", "NFCSettings", "${ it.value }" )
                    break
                case "fingerprintState":
 //                   PostStateToChild( "${ Device }", "FingerprintState", "${ it.value }" )
                    break
                case "nfcState":
 //                   PostStateToChild( "${ Device }", "NFCState", "${ it.value }" )
                    break
                case "isPairedWithAiPort":
 //                   PostStateToChild( "${ Device }", "PairedWithAiPort", "${ it.value }" )
                    break
                case "smartDetectLoiterZones":
 //                   PostStateToChild( "${ Device }", "SmartDetectLoiterZones", "${ it.value }" )
                    break
                case "ptzControlEnabled":
 //                   PostStateToChild( "${ Device }", "PTZControlEnabled", "${ it.value }" )
                    break
                case "lcdMessage":
                	if( it.value != null ){
                        if( it.value.text != null ){
                            PostEventToChild( "${ Device }", "Notification", "${ it.value.text }" )
                        }
                    }
                	break
                case "externalLeakDetectedAt":
//                	PostStateToChild( "${ Device }", "ExternalLeakDetectedAt", "${ it.value }" )
                    break
                case "leakSettings":
//                	PostStateToChild( "${ Device }", "LeakSettings", "${ it.value }" )
                    break
                case "functionButtonPressedAt":
//                	PostStateToChild( "${ Device }", "FunctionButtonPressedAt", "${ it.value }" )
                    break
                case "isBlockedByArmMode":
//                	PostStateToChild( "${ Device }", "IsBlockedByArmMode", ConvertBoolean( it.value ) )
                    break
                case "armMode":
//                	PostStateToChild( "${ Device }", "ArmMode", "${ it.value }" )
                    break
                case "channels":
                	if( it.value != null ){
                		PostStateToChild( "${ Device }", "Channels", it.value )
                        if( it.value[ 0 ] != null ){
                        	if( it.value[ 0 ].isRtspEnabled != null ){
                            	if( it.value[ 0 ].isRtspEnabled == true ){
                                	PostEventToChild( "${ Device }", "Stream_High", "Enabled" )
                            	} else {
                                	PostEventToChild( "${ Device }", "Stream_High", "Disabled" )
                            	}
                            }
                        }
                        if( it.value[ 1 ] != null ){
                            if( it.value[ 1 ].isRtspEnabled != null ){
                                if( it.value[ 1 ].isRtspEnabled == true ){
                                    PostEventToChild( "${ Device }", "Stream_Medium", "Enabled" )
                                } else {
                                    PostEventToChild( "${ Device }", "Stream_Medium", "Disabled" )
                                }
                            }
                        }
                        if( it.value[ 2 ] != null ){
                            if( it.value[ 2 ].isRtspEnabled != null ){
                                if( it.value[ 2 ].isRtspEnabled == true ){
                                    PostEventToChild( "${ Device }", "Stream_Low", "Enabled" )
                                } else {
                                    PostEventToChild( "${ Device }", "Stream_Low", "Disabled" )
                                }
                            }
                        }
                    }
                    break
                case "recordingSettings":
                	if( it.value != null ){
                        if( it.value.mode != null ){
                			if( it.value.mode == "always" ){
                				PostEventToChild( "${ Device }", "RecordingMode", "Always" )
                    		} else if( it.value.mode == "never" ){
                				PostEventToChild( "${ Device }", "RecordingMode", "Never" )
                    		} else if( it.value.mode == "schedule" ){
                        		PostEventToChild( "${ Device }", "RecordingMode", "Schedule" )
                            } else {
                                Logging( "Unhandled recording mode ${ it.value.mode } received.", 3 )
                            }
                        }
                    }
                	break
                case "alarmSilencedAt":
//                	PostStateToChild( "${ Device }", "AlarmSilenced", it.value )
                	break
                case "ptz":
//                	PostStateToChild( "${ Device }", "PTZ", it.value )
                	break
                case "readerSettings":
//                	PostStateToChild( "${ Device }", "ReaderSettings", it.value )
                	break
                case "isIntercom":
//                    PostStateToChild( "${ Device }", "IsIntercom", ConvertBoolean( it.value ) )
                	break
                case "interfaceSettings":
//                	PostStateToChild( "${ Device }", "InterfaceSettings", it.value )
                	break
                case "faceUnlockSettings":
//                	PostStateToChild( "${ Device }", "FaceUnlockSettings", it.value )
                	break
                case "brightnessSettings":
                	if( it.value.brightness != null ){
//                    	PostStateToChild( "${ Device }", "Brightness", it.value.brightness )
                    }
                	if( it.value.autoBrightness != null ){
//                        PostStateToChild( "${ Device }", "AutoBrightness", ConvertBoolean( it.value.autoBrightness ) )
                    }
                	break
                case "greetingSettings":
//                	PostStateToChild( "${ Device }", "GreetingSettings", it.value )
                	break
                case "isAccessDevice":
//                    PostStateToChild( "${ Device }", "IsAccessDevice", ConvertBoolean( it.value ) )
                	break
                case "wirelessConnectionState":
//                	PostStateToChild( "${ Device }", "WirelessConnectionState", it.value )
                	break
                case "troubleSilencedAt":
//                	PostStateToChild( "${ Device }", "TroubleSilencedAt", it.value )
                	break
                case "connectionType":
//                	PostStateToChild( "${ Device }", "ConnectionType", it.value )
                	break
                case "smokeStatus":
                	if( ( SensorType == "UP Sense" ) || ( SensorType == "USL Environmental" ) || ( SensorType == null ) ){
//                		PostEventToChild( "${ Device }", "smoke", it.value )
                    }
                	break
                case "glassBreakSettings":
                	if( ( SensorType == "UP Sense" ) || ( SensorType == "USL Environmental" ) || ( SensorType == null ) ){
//                		PostStateToChild( "${ Device }", "GlassBreakSettings", it.value )
                    }
                	break
                case "wirelessConnectionSettings":
//                	PostStateToChild( "${ Device }", "WirelessConnectionSettings", it.value )
                	break
                case "switchPoeBudget":
//                	PostStateToChild( "${ Device }", "SwitchPoEBudget", it.value )
                	break
                case "allowThirdPartyNfcCards":
//                	PostStateToChild( "${ Device }", "Allow3rdPartyNFC", ConvertBoolean( it.value ) )
                	break
                case "voipForbidden":
                case "skipCameraUpdateDecalListener":
//                	PostStateToChild( "${ Device }", it.key, ConvertBoolean( it.value ) )
                	break
                case "airQuality":
                case "airQualitySettings":
                	if( ( SensorType == "UP Sense" ) || ( SensorType == "USL Environmental" ) || ( SensorType == null ) ){
//                		PostStateToChild( "${ Device }", it.key, it.value )
                    }
                	break
                case "featureFlags":
                	def TempString = ""
                	it.value.each(){
                        switch( it.key ){
                            case "isPtz":
                            case "canOpticalZoom":
                            case "hasWifi":
                            case "hasMic":
                            case "isDoorbell":
                            case "hasSmartDetect":
                            case "hasInfrared":
                            case "hasSpeaker":
                            case "hasTwoWayAudioMediaStreams":
                            case "homekitPaired":
							case "supportPtzVehicleTracking":
                            case "hasMotionDetection":
   //                             PostStateToChild( "${ Device }", it.key, ConvertBoolean( it.value ) )
                            	break
                            case "button":
                            case "waterLeak":
                            case "light":
                            case "temperature":
                            case "humidity":
                            case "motion":
                            case "tamper":
                            case "led":
                            case "alarmTypes":
                            case "open":
                            case "acceleration":
                            case "storage":
   //                         	PostStateToChild( "${ Device }", "Feature_${ it.key }", it.value )
                            	break
                            // Ones to ignore for now
                            case "useExternalAlarmManager":
                            case "ulpRoleManagement":
                            case "lastMigratedEventId":
                            case "supportAccessAppRingEvent":
                            case "dev":
                            case "supportAccessPlayback":
                            case "externalAlarmManagerReady":
                            case "stackedMigration":
                            case "beta":
                            case "detectionLabels":
                            case "smartDoorAccess":
                            case "hasSessionStats":
                            case "notificationsV2":
                            case "motionAlgorithms":
                            case "reader":
                            case "focus":
                            case "hasMotionZones":
                            case "tilt":
                            case "canMagicZoom":
                            case "hasHallwayModeHdrOnRequired":
                            case "hasColorLcdScreen":
                            case "hasPackageZoneSupportForSecondaryLens":
                            case "hasPrivacyMask":
                            case "presetTour":
                            case "hasSmokeCover":
                            case "hasChime":
                            case "hasVerticalFlip":
                            case "hasLprReflex":
                            case "lensModel":
                            case "pan":
                            case "verticalFlipWarning":
                            case "hasHorizontalFlip":
                            case "flashRange":
                            case "hasBluetooth":
                            case "hasManualPersonOfInterest":
                            case "smartDetectAudioTypes":
                            case "supportLpDetectionWithoutVehicle":
                            case "hasLiveviewTracking":
                            case "smartDetectTypes":
                            case "supportNfc":
                            case "hasPackageCamera":
                            case "hasHallwayMode":
                            case "canTouchFocus":
                            case "presetMinDuration":
                            case "privacyMaskCapability":
                            case "hasLuxCheck":
                            case "hasAec":
                            case "supportFullHdSnapshot":
                            case "supportMinMotionAdaptiveBitrate":
                            case "hasAutoICROnly":
                            case "hasLineIn":
                            case "hasExternalIr":
                            case "canAdjustIrLedLevel":
                            case "hasLedIr":
                            case "videoModeMaxFps":
                            case "streamEncryptable":
                            case "hasIcrSensitivity":
                            case "audioStyle":
                            case "canAdjustIspSettings":
                            case "hasFisheye":
                            case "hasWdr":
                            case "audioCodecs":
                            case "hotplug":
                            case "audio":
                            case "lensType":
                            case "hasEdgeRecording":
                            case "clarityZones":
                            case "videoInputModes":
                            case "hasRtc":
                            case "videoModes":
                            case "excludeZones":
                            case "maxScaleDownLevel":
                            case "zoom":
                            case "hasAccelerometer":
                            case "hasLcdScreen":
                            case "hasSmartZoom":
                            case "hasLineCrossingCounting":
                            case "supportCustomRingtone":
                            case "hasSdCard":
                            case "hasTamperDetection":
                            case "canAdjustSpeakerVolume":
                            case "hasLdc":
                            case "hasFlash":
                            case "videoCodecs":
                            case "hasHdr":
                            case "hasOptimizeIr":
                            case "stitchDistance":
                            case "hasLedStatus":
                            case "hasLineCrossing":
                            case "mountPositions":
                            case "supportDoorAccessConfig":
                            case "hasPackageZoneSupportForPrimaryLens":
                            case "hasSquareEventThumbnail":
                            case "supportLocate":
                            case "hasFingerprintSensor":
                            case "supportPtzTrackingTimeout":
                            case "msIdSupport":
                            case "hallwayModeWarningRequired":
                            case "videoDeviceCount":
                            case "downScaleResolutions":
                            case "autoRetentionSupported":
                            case "supportGifInterfaceImage":
                            case "supportsExpansionUnits":
                            case "aiFeatureFlag":
                            case "downScaleLevels":
                            case "isBidirectional":
                            	break
                            default:
                            	TempString += "${ it.key }=${ it.value } "
                            	break
                        }
                    }
                	if( TempString != "" ){
                		Logging( "Unhandled Feature Flags ${ TempString }", 3 )
                    }
                	break
                case "estimatedLqRetentionDays":
                	if( it.value != null ){
//                        PostStateToChild( "${ Device }", EstimatedLowQualityDays, Math.round( it.value ) )
                    } else {
//                    	PostStateToChild( "${ Device }", EstimatedLowQualityDays, 0 )
                    }
                	break
                case "estimatedHqRetentionDays":
                	if( it.value != null ){
//                        PostStateToChild( "${ Device }", EstimatedHighQualityDays, Math.round( it.value ) )
                    } else {
//                    	PostStateToChild( "${ Device }", EstimatedHighQualityDays, 0 )
                    }
                	break
                case "storageAllocationHqPercent":
//                	PostStateToChild( "${ Device }", StorageAllocationHighQuality, it.value )
                	break
                case "storageAllocationLqPercent":
//                	PostStateToChild( "${ Device }", StorageAllocationLowQuality, it.value )
                	break
                case "storageAllocationMode":
//                	PostStateToChild( "${ Device }", StorageAllocationMode, it.value )
                	break
                // Not sure the specific value but providing them as a state
                case "updateInterval":
                case "ulpVersion":
                case "dbRecoveryOptions":
                case "foreignPgDumpDetected":
                case "foreignPgDumpConsoleName":
                case "streamEncryptionEnabled":
                case "secondLensSmartDetectZones":
                case "isAdoptedByAccessApp":
                case "accessDeviceMetadata":
                case "accessVersion":
                case "isHomekitEnabled":
                case "homekitStatus":
                case "homekitError":
                case "liveview":
                case "homekitSetupPayload":
                case "homekitSetupCode":
                case "homekitAccessoryId":
                case "aiPortCapacityPoints":
                case "videoInputMode":
                case "isRecordingsPaused":
                case "recordingsPausedReason":
//                	PostStateToChild( "${ Device }", it.key, it.value )
                    break

                // Not doing anything with this data at this moment. Not sure of value.
                case "portStatus":
                case "globalCameraSettings":
                case "switchPorts":
                case "videoCodecLastSwitchAt":
                    break
				// Ignored data - limited use at this time or redundant
                case "totalLqBytesPerDay":
                case "totalHqBytesPerDay":
                case "hasBackportedRetentionSettings":
                case "storageAllocationHqPercentBalanced":
                case "autoBalanceStorageBytes":
                case "autoRetentionSupported":
                case "autoBalanceStorageBytes":
                case "autoRetentionEnabled":
                case "storageAllocationHqPercentMaxRetention":
                case "autoRetentionMs":
                case "autoRetentionLqMs":
                case "autoRetentionHqMs":
                case "lqBytesPerDay":
                case "hqBytesPerDay":
                case "isDbAvailable":
                case "streamSharingAvailable":
                case "streamSharing":
				case "lightOnSettings":
				case "upSince":
				case "lastSeen":
				case "isCameraPaired":
				case "canAdopt":
				case "isSshEnabled":
				case "wiredConnectionState":
				case "connectedSince":
				case "connectionHost":
				case "host":
				case "isUpdating":
				case "isLocating":
				case "isAdopted":
				case "isAttemptingToConnect":
				case "isAdoptedByOther":
				case "modelKey":
				case "lastMotion":
				case "firmwareBuild":
				case "isAdopting":
				case "isProvisioned":
				case "isRebooting":
                case "phyRate":
                case "smartDetectSettings":
                case "isRecording":
                case "isSmartDetected":
                case "isProbingForWifi":
                case "lenses":
                case "eventStats":
                case "privacyZones":
                case "apMac":
                case "hdrMode":
                case "isManaged":
                case "videoReconfigurationInProgress":
                case "isLiveHeatmapEnabled":
                case "talkbackSettings":
                case "ledSettings":
                case "speakerSettings":
                case "isPoorNetwork":
                case "hasWifi":
                case "videoMode":
                case "recordingSchedules":
                case "ispSettings":
                case "smartDetectZones":
                case "smartDetectLines":
                case "micVolume":
                case "pirSettings":
                case "isMicEnabled":
                case "isWirelessUplinkEnabled":
                case "isDeleting":
                case "lastRing":
                case "anonymousDeviceId":
                case "hasSpeaker":
                case "wifiConnectionState":
                case "elementInfo":
                case "lastPrivacyZonePositionId":
                case "audioBitrate":
                case "voltage":
                case "canManage":
                case "apRssi":
                case "marketName":
                case "motionZones":
                case "chimeDuration":
                case "osdSettings":
                case "analyticsData":
                case "isRecordingDisabled":
                case "skipFirmwareUpdate":
                case "errorCode":
                case "enableCrashReporting":
                case "isRecordingMotionOnly":
                case "hostType":
                case "isStatsGatheringEnabled":
                case "recordingRetentionDurationMs":
                case "isAway":
                case "isHardware":
                case "enableAutomaticBackups":
                case "isSetup":
                case "enableStatsReporting":
                case "hardwarePlatform":
                case "canAutoUpdate":
                case "hosts":
                case "disableAutoLink":
                case "isRecycling":
                case "storageStats":
                case "releaseChannel":
                case "hardwareId":
                case "cameraUtilization":
                case "timezone":
                case "wifiSettings":
                case "smartDetectAgreement":
                case "ports":
                case "network":
                case "ucoreVersion":
                case "temperatureUnit":
                case "ssoChannel":
                case "disableAudio":
                case "lastUpdateAt":
                case "hostShortname":
                case "doorbellSettings":
                case "uiVersion":
                case "enableBridgeAutoAdoption":
                case "maxCameraCapacity":
                case "isStation":
                case "timeFormat":
                case "locationSettings":
                case "avgMotions":
                case "lastDriveSlowEvent":
                case "isStacked":
                case "isPrimary":
                case "isUCoreSetup":
                case "isDownloadingFW":
                case "isInsightsEnabled":
                case "guid":
                case "bridgeCandidates":
                case "vaultCameras":
                case "hasGateway":
                case "isVaultRegistered":
                case "stopStreamLevel":
                case "userConfiguredAp":
                case "useGlobal":
                case "apMgmtIp":
                case "isRestoring":
                case "isProtectUpdatable":
                case "hardDriveState":
                case "isUcoreUpdatable":
                case "lastDeviceFWUpdatesCheckedAt":
                case "audioSettings":
                case "isUCoreStacked":
                case "timelapseEnabled":
                case "consoleEnv":
                case "agreements":
                case "isExtenderInstalledEver":
                case "videoCodecSwitchingSince":
                case "downScaleMode":
                case "hubMac":
                case "activePatrolSlot":
                case "videoCodecState":
                case "sysid":
                case "chosenBridge":
                case "enableNfc":
                case "isRemoteAccessEnabled":
                case "isMissingRecordingDetected":
                case "isLightForceEnabled":
                case "latestFirmwareSizeBytes":
                case "isSecondary":
                case "hdrType":
                case "hallwayMode":
                case "wanPorts":
                case "cefSettings":
                case "rtspClient":
                case "optimizeIrSettings":
                case "supportAiPortResolutionInHallway":
                case "clarityZones":
                case "supportUcp4":
                case "accessMethodSettings":
                case "isReaderPro":
                case "canCreateAccessEvent":
                case "parentCameraGroupId":
                case "needUpdateBeforeAdoption":
                case "pinCodeSettings":
                case "stitchDistance":
                case "excludeZones":
                case "globalAlarmManagerScopeNames":
                case "msrServiceState":
                case "msrServiceMeta":
                case "homekitShutdownReason":
                case "isMigrationFailed":
                case "supportFileCreatedAt":
                case "supportFileName":
                case "supportFileState":
                case "sessionSettings":
                case "aiPostProcessing":
                case "iPortCompatibleResolutionsInHallway":
                case "receiverGroups":
                case "recordingPath":
                case "hasRecordingStarted":
                case "isAccessFloodlightTriggerEnabled":
                case "template":
                case "doorbellSession":
                case "aiPortCompatibleResolutions":
                case "supportAiPortResolution":
                case "aiPortCompatibleResolutionsInHallway":
                case "isReverting":
                case "minFirmwareVersion":
                case "previousFirmwareVersion":
                case "previousFirmwareUrl":
                case "storageConsoleCameraCounts":
                case "syncingProgress":
                case "expansionUnitRetention":
                case "expansionUnits":
                case "syncingSince":
                case "aiFeatureSettings":
                case "storageConsoleFailoverSettings":
                case "isFullBackupPreparing":
                case "isEdgeDevice":
                case "isFullBackupReady":
                case "syncingEstimateMs":
                case "isRecordingPauseAllowedDuringRaidSync":
                case "lowMemoryDisabledProcesses":
                case "recordingPathSettings":
                case "recordingPathFailedAt":
                case "hasPackageCamera":
              	case "isRecordingsPausedChangedAt":
					break
                default:
                    Logging( "Unhandled data for ${ Device } ${ it.key } = ${ it.value }", 3 )
                    break
            }
        }
    }
}

// Handles data sent from a child to the parent for processing
def ReceiveFromChild( String Type, String Child, Map Data ){
    Logging( "Received ${ Type } from ${ Child } = ${ Data }", 4 )
    switch( Type ){
        case "State":
            ProcessState( "${ Data.Name }", Data.Value )
            break
        case "Event":
            ProcessEvent( "${ Data.Name }", Data.Value )
            break
        case "Logging":
            Logging( "Log from ${ Child }: ${  Data.Value }", Data.Level )
            break
        case "Map":
            Data.each(){
                switch( it.value.Type ){
                    case "State":
                        ProcessState( "${ it.value.Name }", it.value.Value )
                        break
                    case "Event":
                        ProcessEvent( "${ it.value.Name }", it.value.Value )
                        break
                    case "Logging":
                        Logging( "Log from ${ Child }: ${  it.value.Value }", it.value.Level )
                        break
                    default:
                        Logging( "Test of ReceiveFromChild = Map = HUH?! ${ Child }, Map Data = ${ it }", 4 )
                        break
                }
            }
            break
        default:
            Logging( "Unhandled ${ Type } ReceiveFromChild: ${ Child }, Data=${ Data }", 3 )
            break
    }
}

// installed is called when the device is installed
def installed(){
	Logging( "Installed", 2 )
}

// uninstalling device so make sure to clean up children
void uninstalled() {
    // Delete all children
    getChildDevices().each{
        deleteChildDevice( it.deviceNetworkId )
    }
    unschedule()
    CloseWebSocket()
    Logging( "Uninstalled", 2 )
}

// Used to convert boolean to string
def ConvertBoolean( Value ){
    if( Value ){
        return "true"
    } else {
        return "false"
    }
}

// Used to convert epoch values to text dates
def String ConvertEpochToDate( String Epoch ){
    def date
    if( ( Epoch != null ) && ( Epoch != "" ) && ( Epoch != "null" ) ){
        Long Temp = Epoch.toLong()
        if( Temp <= 9999999999 ){
            date = new Date( ( Temp * 1000 ) ).toString()
        } else {
            date = new Date( Temp ).toString()
        }
    } else {
        date = "Null value provided"
    }
    return date
}

// Checks the location.getTemperatureScale() to convert temperature values
def ConvertTemperature( String Scale, Number Value ){
    if( Value != null ){
        def ReturnValue = Value as double
        if( location.getTemperatureScale() == "C" && Scale.toUpperCase() == "F" ){
            ReturnValue = ( ( ( Value - 32 ) * 5 ) / 9 )
            Logging( "Temperature Conversion ${ Value }°F to ${ ReturnValue }°C", 4 )
        } else if( location.getTemperatureScale() == "F" && Scale.toUpperCase() == "C" ) {
            ReturnValue = ( ( ( Value * 9 ) / 5 ) + 32 )
            Logging( "Temperature Conversion ${ Value }°C to ${ ReturnValue }°F", 4 )
        } else if( ( location.getTemperatureScale() == "C" && Scale.toUpperCase() == "C" ) || ( location.getTemperatureScale() == "F" && Scale.toUpperCase() == "F" ) ){
            ReturnValue = Value
        }
        def TempInt = ( ReturnValue * 100 ) as int
        ReturnValue = ( TempInt / 100 )
        return ReturnValue
    }
}

// Send event for device
def ProcessEvent( Variable, Value, Unit = null, Description = null ){
    sendEvent( name: Variable, value: Value, unit: Unit, descriptionText: Description )
    if( Unit != null ){
        if( Description != null ){
            Logging( "Event: ${ Variable } = ${ Value } Unit = ${ Unit } Description = ${ Description }", 4 )
        } else {
            Logging( "Event: ${ Variable } = ${ Value } Unit = ${ Unit }", 4 )
        }
    } else {
        if( Description != null ){
            Logging( "Event: ${ Variable } = ${ Value } Description = ${ Description }", 4 )
        } else {
            Logging( "Event: ${ Variable } = ${ Value }", 4 )
        }
    }
    ProcessState( Variable, Value )
}

// Set a state variable to a value
def ProcessState( Variable, Value ){
    Logging( "State: ${ Variable } = ${ Value }", 4 )
    state."${ Variable }" = Value
    //UpdateTile( "${ Value }" )
}

// Set a child device's parameter
def SetChildParameter( Child, Parameter, Value ){
    if( Child != null ){
        if( getChildDevice( Child ) == null ){
            TempChild = Child.split( " " )
            def ChildType = ""
            switch( TempChild[ 0 ] ){
                case "Light":
                    ChildType = "Light"
                    break
                case "Doorbell":
                    ChildType = "Doorbell"
                    break
                case "Camera":
                    ChildType = "Camera"
                    break
                case "PTZCamera":
                    ChildType = "PTZCamera"
                    break
                case "Bridge":
                    ChildType = "Bridge"
                    break
                case "Sensor":
                    ChildType = "Sensor"
                    break
                default:
                    ChildType = "Generic"
                    break
            }
            addChild( Child, ChildType )
        }
        if( getChildDevice( Child ) != null ){
            Logging( "Setting ${ Child } Parameter ${ Parameter } to ${ Value }", 4 )
            getChildDevice( Child ).updateSetting( Parameter, Value )
        } else {
            def TempString = "Failure to add ${ Child } and parameter: ${ Parameter } = ${ Value }"
    		Logging( TempString, 5 )
        }
    } else {
        Logging( "Failure to add child because child name was null", 5 )
    }
}

// Post data to child device
def PostEventToChild( Map data ){
    PostEventToChild( data.Device, data.Variable, data.Value, data.Unit, data.Description )
}

// Post data to child device
def PostEventToChild( Child, Variable, Value, Unit = null, Description = null ){
    if( Child != null ){
        if( getChildDevice( Child ) == null ){
            TempChild = Child.split( " " )
            def ChildType = ""
            switch( TempChild[ 0 ] ){
                case "Light":
                    ChildType = "Light"
                    break
                case "Doorbell":
                    ChildType = "Doorbell"
                    break
                case "Camera":
                    ChildType = "Camera"
                    break
                case "PTZCamera":
                    ChildType = "PTZCamera"
                    break
                case "Bridge":
                    ChildType = "Bridge"
                    break
                case "Sensor":
                    ChildType = "Sensor"
                    break
                default:
                    ChildType = "Generic"
                    break
            }
            addChild( Child, ChildType )
        }
        if( getChildDevice( Child ) != null ){
            Logging( "Posting Event ${ Variable } = ${ Value } to ${ Child }", 4 )
            getChildDevice( Child ).ProcessEvent( Variable, Value, Unit, Description )
        } else {
            def TempString = "Failure to add ${ Child } and event: ${ Variable } = ${ Value }"
    		if( Unit != null ){
        		TempString += " Unit = ${ Unit }"
    		}
    		if( Description != null ){
        		TempString += " Description = ${ Description }"
    		}
    		Logging( TempString, 5 )
        }
    } else {
        Logging( "Failure to add child because child name was null", 5 )
    }
}

// Post data to child device
def PostStateToChild( Child, Variable, Value ){
    if( Child != null ){
        if( getChildDevice( Child ) == null ){
            TempChild = Child.split( " " )
            def ChildType = ""
            switch( TempChild[ 0 ] ){
                case "Light":
                    ChildType = "Light"
                    break
                case "Doorbell":
                    ChildType = "Doorbell"
                    break
                case "Camera":
                    ChildType = "Camera"
                    break
                case "PTZCamera":
                    ChildType = "PTZCamera"
                    break
                case "Bridge":
                    ChildType = "Bridge"
                    break
                case "Sensor":
                    ChildType = "Sensor"
                    break
                default:
                    ChildType = "Generic"
                    break
            }
            addChild( Child, ChildType )
        }
        if( getChildDevice( Child ) != null ){
            getChildDevice( Child ).ProcessState( Variable, Value )
        } else {
            Logging( "Failure to add ${ Child } and state ${ Variable }=${ Value }", 5 )
        }
    } else {
        Logging( "Failure to add child because child name was null", 5 )
    }
}

// Adds a UnifiProtectChild child device
// Based on @mircolino's method for child sensors
def addChild( String DNI, String ChildType ){
    try{
        Logging( "addChild(${ DNI })", 4 )
        switch( ChildType ){
            case "Light":
                addChildDevice( "UnifiProtectChild-Light", DNI, [ name: "${ DNI }" ] )
                break
            case "Camera":
                addChildDevice( "UnifiProtectChild-Camera", DNI, [ name: "${ DNI }" ] )
                break
            case "PTZCamera":
                addChildDevice( "UnifiProtectChild-PTZCamera", DNI, [ name: "${ DNI }" ] )
                break
            case "Doorbell":
                addChildDevice( "UnifiProtectChild-Doorbell", DNI, [ name: "${ DNI }" ] )
                break
            case "Bridge":
                addChildDevice( "UnifiProtectChild-Bridge", DNI, [ name: "${ DNI }" ] )
                break
            case "Sensor":
                addChildDevice( "UnifiProtectChild-Sensor", DNI, [ name: "${ DNI }" ] )
                break
            default:
                addChildDevice( "UnifiProtectChild", DNI, [ name: "${ DNI }" ] )
                break
        }
    }
    catch( Exception e ){
        def Temp = e as String
        if( Temp.contains( "not found" ) ){
            if( ChildType != null ){
                Logging( "UnifiProtectChild-${ ChildType } driver is not loaded, this is required for the child device.", 5 )
            } else {
                Logging( "UnifiProtectChild driver is not loaded, this is required for the child device.", 5 )
            }
        } else {
            Logging( "addChild Error, likely child already exists: ${ Temp }", 5 )
        }
    }
}

// Handles whether logging is enabled and thus what to put there.
def Logging( LogMessage, LogLevel ){
	// Add all messages as info logging
    if( ( LogLevel == 2 ) && ( LogType != "None" ) ){
        log.info( "${ device.displayName } - ${ LogMessage }" )
    } else if( ( LogLevel == 3 ) && ( ( LogType == "Debug" ) || ( LogType == "Trace" ) ) ){
        log.debug( "${ device.displayName } - ${ LogMessage }" )
    } else if( ( LogLevel == 4 ) && ( LogType == "Trace" ) ){
        log.trace( "${ device.displayName } - ${ LogMessage }" )
    } else if( LogLevel == 5 ){
        log.error( "${ device.displayName } - ${ LogMessage }" )
    }
}

// Checks drdsnell.com for the latest version of the driver
// Original inspiration from @cobra's version checking
def CheckForUpdate(){
    ProcessEvent( "DriverName", DriverName() )
    ProcessEvent( "DriverVersion", version() )
	httpGet( uri: "https://www.drdsnell.com/projects/hubitat/drivers/versions.json", contentType: "application/json" ){ resp ->
        switch( resp.status ){
            case 200:
                if( resp.data."${ DriverName() }" ){
                    CurrentVersion = version().split( /\./ )
                    if( resp.data."${ DriverName() }".version == "REPLACED" ){
                       ProcessEvent( "DriverStatus", "Driver replaced, please use ${ resp.data."${ state.DriverName }".file }" )
                    } else if( resp.data."${ DriverName() }".version == "REMOVED" ){
                       ProcessEvent( "DriverStatus", "Driver removed and no longer supported." )
                    } else {
                        SiteVersion = resp.data."${ DriverName() }".version.split( /\./ )
                        if( CurrentVersion == SiteVersion ){
                            Logging( "Driver version up to date", 2 )
				            ProcessEvent( "DriverStatus", "Up to date" )
                        } else if( ( CurrentVersion[ 0 ] as int ) > ( SiteVersion [ 0 ] as int ) ){
                            Logging( "Major development ${ CurrentVersion[ 0 ] }.${ CurrentVersion[ 1 ] }.${ CurrentVersion[ 2 ] } version", 4 )
				            ProcessEvent( "DriverStatus", "Major development ${ CurrentVersion[ 0 ] }.${ CurrentVersion[ 1 ] }.${ CurrentVersion[ 2 ] } version" )
                        } else if( ( CurrentVersion[ 1 ] as int ) > ( SiteVersion [ 1 ] as int ) ){
                            Logging( "Minor development ${ CurrentVersion[ 0 ] }.${ CurrentVersion[ 1 ] }.${ CurrentVersion[ 2 ] } version", 4 )
				            ProcessEvent( "DriverStatus", "Minor development ${ CurrentVersion[ 0 ] }.${ CurrentVersion[ 1 ] }.${ CurrentVersion[ 2 ] } version" )
                        } else if( ( CurrentVersion[ 2 ] as int ) > ( SiteVersion [ 2 ] as int ) ){
                            Logging( "Patch development ${ CurrentVersion[ 0 ] }.${ CurrentVersion[ 1 ] }.${ CurrentVersion[ 2 ] } version", 4 )
				            ProcessEvent( "DriverStatus", "Patch development ${ CurrentVersion[ 0 ] }.${ CurrentVersion[ 1 ] }.${ CurrentVersion[ 2 ] } version" )
                        } else if( ( SiteVersion[ 0 ] as int ) > ( CurrentVersion[ 0 ] as int ) ){
                            Logging( "New major release ${ SiteVersion[ 0 ] }.${ SiteVersion[ 1 ] }.${ SiteVersion[ 2 ] } available", 2 )
				            ProcessEvent( "DriverStatus", "New major release ${ SiteVersion[ 0 ] }.${ SiteVersion[ 1 ] }.${ SiteVersion[ 2 ] } available" )
                        } else if( ( SiteVersion[ 1 ] as int ) > ( CurrentVersion[ 1 ] as int ) ){
                            Logging( "New minor release ${ SiteVersion[ 0 ] }.${ SiteVersion[ 1 ] }.${ SiteVersion[ 2 ] } available", 2 )
				            ProcessEvent( "DriverStatus", "New minor release ${ SiteVersion[ 0 ] }.${ SiteVersion[ 1 ] }.${ SiteVersion[ 2 ] } available" )
                        } else if( ( SiteVersion[ 2 ] as int ) > ( CurrentVersion[ 2 ] as int ) ){
                            Logging( "New patch ${ SiteVersion[ 0 ] }.${ SiteVersion[ 1 ] }.${ SiteVersion[ 2 ] } available", 2 )
				            ProcessEvent( "DriverStatus", "New patch ${ SiteVersion[ 0 ] }.${ SiteVersion[ 1 ] }.${ SiteVersion[ 2 ] } available" )
                        }
                    }
                } else {
                    Logging( "${ DriverName() } is not published on drdsnell.com", 2 )
                    ProcessEvent( "DriverStatus", "${ DriverName() } is not published on drdsnell.com" )
                }
                break
            default:
                Logging( "Unable to check drdsnell.com for ${ DriverName() } driver updates.", 2 )
                break
        }
    }
}

// Pre-cache device lookup if this is called often
def deviceLookupLoad () {
    getChildDevices().each { device ->
        def id = device.ReturnState("ID")
        if (id) {
            deviceLookup[id] = device.deviceNetworkId
        }
    }
}
