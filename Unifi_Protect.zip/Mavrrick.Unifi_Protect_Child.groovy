library (
 author: "Mavrrick",
 category: "Unifi",
 description: "Unifi Protect Child Devices",
 name: "Unifi_Protect_Child",
 namespace: "Mavrrick",
 documentationLink: "http://www.example.com/"
)

//@Field static Number procTime = 0
//@Field static Number callCount = 0
//@Field static Number updates = 0


def childPost( Map Data ){
    long startTime = now()
    long updates = 0
//    log.info "childPost() ChildPost call started at ${startTime}"
        def modelKey = Data.actionPacket.modelKey
        def EventID
        def TempID
        if( Data.actionPacket.recordId != null ){
            TempID = Data.actionPacket.recordId
            if( TempID != null ){
                if( TempID.indexOf( "-" ) != -1 ){
                    TempID = Data.actionPacket.recordId.split( "-" )
                    EventID = TempID[ 0 ]
                    TempID = TempID[ 1 ]
                } else {
                    EventID = TempID
                }
            }
        } else if( Data.actionPacket.id != null ){
            TempID = Data.actionPacket.id
            if( TempID.indexOf( "-" ) != -1 ){
                TempID = Data.actionPacket.id.split( "-" )
                EventID = TempID[ 0 ]
                TempID = TempID[ 1 ]
            } else {
                EventID = TempID
            }
        } else if( Data.actionPacket.authorizationModelId != null ){
            TempID = Data.actionPacket.authorizationModelId
            EventID = TempID
        } else if( Data.dataPacket?.metadata?.sensorId?.text != null ){
            TempID = Data.dataPacket.metadata.sensorId.text
        }
        def LastAction = state.LastWSSAction
        def LastActionID = state.LastWSSID    
        def Device = device.getLabel() ? device.getLabel() : device.getName()
        if( Data.dataPacket != null ){
            Logging( "${ Device } dataPacket = ${ Data.dataPacket }", 4 )
            
            Data.dataPacket.each(){
            Logging( "${ Device } DataPayload ${ it.key } = ${ it.value }", 4 )
            switch( it.key ){
                case "lastMotion":
                    if( it.value != null ){
                        ProcessEvent( "${ Device }", "LastMotion", ConvertEpochToDate( "${ it.value }" ) )
                    }
                    break
                case "lastRing":
                    if( it.value != null ){
                        //getChildDevice( "${ Device }" ).push( 1 )
                    }
                    break
                case "isDark":
                    ProcessEvent( "${ Device }", "Dark", ConvertBoolean( it.value ), null )
                    if( Data.actionPacket?.actionPayload?.action?.toString() == "add" ){
						ProcessState( "LastWSSAction", "Dark" )
                    }
                    ProcessState( "${ Device }", "LastWSSAction", "Dark" )
                    updates++
				    break
				case "isMotionDetected":
                    Logging( "isMotionDetected on ${ Device } is ${ it.value }", 4 )
                    if( it.value ){
                        ProcessEvent( "${ Device }", "motion", "active" )
                   		if( Device.split( " " )[ 0 ] == "Sensor" ){
                       		def MotionDuration = state.MotionDuration
//             					def ChildID = getChildDevice( "${ Device }" ).ReturnState( "ID" )
               				if( state.MotionDuration == null ){
                  				state.MotionDuration = 15
                            }
                   			if( ChildID != null ){
                        	    runIn( state.MotionDuration, "GetSensorStatus", [ data: [ Device: "${ Device }", ChildID: "${ state.ID	 }" ] ] ) // may need to be looked at further.
                        	}
                        }
                   	} else {
                        ProcessEvent( "motion", "inactive" )
                    }
                    if( Data.actionPacket?.action?.toString() == "add" ){
		    			ProcessState( "LastWSSAction", "motionDetected" )
                    }
                    ProcessState( "LastWSSAction", "motionDetected" )
                    updates++
					break
				case "isPirMotionDetected":
                    Logging( "isPirMotionDetected on ${ Device } is ${ it.value }", 4 )
					if( it.value ){
	 					ProcessEvent( "motion", "active" )
                    } else {
						ProcessEvent( "motion", "inactive" )
					}
                    if( Data.actionPacket?.action?.toString() == "add" ){
				        ProcessState( "LastWSSAction", "motionDetected" )
                     }
                     ProcessEvent( "LastWSSAction", "motionDetected" )
                     updates++
	    			break
				case "isSmartDetected":
                    Logging( "isSmartDetected on ${ Device } is ${ it }", 4 )
					if( it.value ){
						ProcessEvent( "motion", "active" )
                    } else {
                        ProcessEvent( "motion", "inactive" )
                        ProcessEvent( "smartDetectType", "none" )
					}
                    if( Data.actionPacket?.action?.toString() == "add" ){
				        ProcessState( "LastWSSAction", "motionDetected" )
                    }
                    ProcessState( "LastWSSAction", "motionDetected" )
                    updates++
                    break
				case "smartDetectTypes":
                    def ActionType
                    if( Data.actionPacket.modelKey != null ){
                        ActionType = "modelKey ${ Data.actionPacket.modelKey }"
                    } else if( Data.actionPacket.authorizationModelKey != null ){
                        ActionType = "authModelKey ${ Data.actionPacket.authorizationModelKey }"
                    }
                    def Size = it.value.size()
                   	def TempString = ""
                    if( Size > 1 ){
                        def Count = 0
                        it.value.each{
                            TempString = TempString + "${ it.toString() }"
                            Count++
                            if( Count < Size ){
                                TempString = TempString + ", "
                            }
                        }
                    ProcessState( "LastWSSAction", "smartDetectType" )
                    } else if( ( Size == 1 ) && ( "${ it.value[ 0 ] }" != null ) && ( "${ it.value[ 0 ] }" != "null" ) ) {
                        TempString = it.value[ 0 ].toString()
                    } else {
                        TempString = "none"
                    }
                    Logging( "WSS smartDetectType processed = ${ TempString }", 4 )
                    ProcessEvent( "smartDetectType", TempString )
                    if( Data.actionPacket?.action?.toString() == "add" ){
                        ProcessState( "LastWSSAction", "smartDetectType" )
                    }
                    ProcessState( "LastWSSAction", "smartDetectType" )
                    updates++
				    break
			    case "isLightOn":
			        if( it.value ){
					    ProcessEvent( "switch", "on" )
					} else {
						ProcessEvent( "switch", "off" )
                    }
                    if( Data.actionPacket?.action?.toString() == "add" ){
					    ProcessState( "LastWSSAction", "Light" )
                    }
                    ProcessState( "LastWSSAction", "Light" )
                    updates++
				    break
			    case "isRecording":
			        if( it.value ){
					    ProcessEvent( "RecordingNow", "true" )
					} else {
						ProcessEvent( "RecordingNow", "false" )
					}
                    if( Data.actionPacket?.action?.toString() == "add" ){
					    ProcessState( "LastWSSAction", "RecordingNow" )
                    }
                    ProcessState( "${ Device }", "LastWSSAction", "RecordingNow" )
				    updates++
                    break
				case "eventStats":
					if( it.value.motion.today != null ){
						ProcessEvent( "MotionEventsToday", it.value.motion.today )
					}
                    updates++
					break
                case "type":
/*                            if( Data.dataPacket != null ){
                                if( Data.dataPacket.device != null ){
                                    getChildDevices().each{
                                        if( Data.dataPacket.device == getChildDevice( it.deviceNetworkId ).ReturnState( "ID" ) ){
                                            Logging( "Changing Device from ${ Device } to ${ it.deviceNetworkId }", 4 )
                                            Device = it.deviceNetworkId
                                        }
                                    }
                                }
                            } */
                    switch( it.value ){                       
                        case "motion":
                            Logging( "SmartDetect Type Motion on ${ Device }", 4 )
                            ProcessEvent( "motion", "active" )
                            if( Data.actionPacket?.action?.toString() == "add" ){
							    ProcessState( "LastWSSAction", "motion" )
                            }
                            ProcessState( "LastWSSAction", "motion" )
                            if( Device.split( " " )[ 0 ] == "Sensor" ){
                                def MotionDuration = state.MotionDuration
//                                        def ChildID = getChildDevice( "${ Device }" ).ReturnState( "ID" )
                                if( state.MotionDuration == null ){
                                    state.MotionDuration = 15
                                }
                                if( ChildID != null ){
                                    runIn( state.MotionDuration, "GetSensorStatus", [ data: [ Device: "${ Device }", ChildID: "${ state.ID }" ] ] ) // neeed to chek what this is doing. May need to make adjustments
                                }
                            }
                            updates++
                            break
                        case "sensorMotion":
                            Logging( "sensorMotion on ${ Device }", 4 )
                            ProcessEvent( "motion", "active" )
                            if( Data.actionPacket?.action?.toString() == "add" ){
							    ProcessState( "LastWSSAction", "sensorMotion" )
                            }
                            ProcessState( "LastWSSAction", "sensorMotion" )
                            if( Device.split( " " )[ 0 ] == "Sensor" ){
                                def MotionDuration = state.MotionDuration
//                                        def ChildID = getChildDevice( "${ Device }" ).ReturnState( "ID" )
                                if( MotionDuration == null ){
                                    MotionDuration = 15
                                }
                                if( ChildID != null ){
                                    runIn( MotionDuration, "GetSensorStatus", [ data: [ Device: "${ Device }", ChildID: "${ state.ID }" ] ] )
                                }
                            }
                            updates++
                            break
                        case "sensorOpened":
                            ProcessEvent( "contact", "open" )
                            if( Data.actionPacket?.action?.toString() == "add" ){
							    ProcessState( "LastWSSAction", "sensorOpened" )
                            }
                            ProcessState( "LastWSSAction", "sensorOpened" )
                            updates++
                            break
                        case "sensorClosed":
                            ProcessEvent( "contact", "closed" )
                            if( Data.actionPacket?.action?.toString() == "add" ){
							    ProcessState( "LastWSSAction", "sensorClosed" )
                            }
                            ProcessState( "LastWSSAction", "sensorClosed" )
                            updates++
                            break
                        case "ring":
                            push( 1 )
                      		if( Data.actionPacket?.action?.toString() == "add" ){
							   ProcessState( "LastWSSAction", "ring" )
                            }
                            ProcessState( "LastWSSAction", "ring" )
                            updates++
                            break
                        case "smartDetectZone":
                            ProcessEvent( "smartDetectZone", "active" )
                            if( Data.actionPacket?.action?.toString() == "add" ){
							    ProcessState( "LastWSSAction", "smartDetectZone" )
                            }
                            ProcessState( "LastWSSAction", "smartDetectZone" )
                            updates++
                            break
                        case "access":
                            ProcessEvent( "access", "active" )
                            if( Data.actionPacket?.action?.toString() == "add" ){
							    ProcessState( "LastWSSAction", "access" )
                            }
                            ProcessState( "LastWSSAction", "access" )
                            updates++
                            break
                        case "deviceDisconnected":
//                                    PostStateToChild( "${ Device }", "DeviceDisconnected", new Date() )
                            break
                        case "fingerprintIdentified":
                            if( Data.dataPacket?.metadata?.fingerprint?.ulpId != null ){
                                ProcessEvent( "FingerprintUserID", "${ Data.dataPacket.metadata.fingerprint.ulpId }" )
                            } else {
                                ProcessEvent( "FingerprintUserID", null )
                                Logging( "No userID found: ${ Data.dataPacket }", 3 )
                            }
                            if( Data.actionPacket?.action?.toString() == "add" ){
                                ProcessState( "LastWSSAction", "fingerprint" )
                            }
                            updates++
                            break
                        case "sensorExtremeValues":
//                                	PostStateToChild( "${ Device }", "SensorExtremeValues", "${ it }" )
                            if( Data.actionPacket?.action?.toString() == "add" ){
							    ProcessState( "LastWSSAction", "sensorExtremeValues" )
                            }
                            ProcessState( "LastWSSAction", "sensorExtremeValues" )
                            updates++
                            break
                        case "poorConnection":
//                                	PostStateToChild( "${ Device }", "DeviceConnection", "Poor" )
                            if( Data.actionPacket?.action?.toString() == "add" ){
							    ProcessState( "LastWSSAction", "poorConnection" )
                            }
                            ProcessState( "LastWSSAction", "poorConnection" )
                            updates++
                            break
                        case "disconnect":
                            Logging( "${ Device } reported a WebSocket disconnect", 4 )
                            if( Data.actionPacket?.action?.toString() == "add" ){
							    ProcessState( "LastWSSAction", "disconnect" )
                            }
                            ProcessState( "LastWSSAction", "disconnect" )
                            updates++
                            break
                        case "smartAudioDetect":
                            ProcessEvent( "sound ", "detected" )
                            if( Data.actionPacket?.action?.toString() == "add" ){
				                ProcessState( "LastWSSAction", "smartAudioDetect" )
                            }
                            ProcessState( "LastWSSAction", "smartAudioDetect" )
                            updates++
                            break
                                // WebSocket data to do nothing for
                        case "lightMotion": // Ignoring as it was seen on NVR in response to floodlight motion being activated
                            break
                        case "type":
                            switch( it.value ){
                                case "sensorButtonPressed":
                                    push( 1 )
                                    break
                                case "sensorTamper":
                                    ProcessEvent( "tamper ", "detected" )
                                    break
                                // Things to do nothing with at present
                                case "deviceAdopted":
                                case "deviceUpdatable":
                                    break
                            default:
                                Logging( "Unhandled WSS Type type for ${ Device }: ${ it }", 3 )
                                break
                            }
                            updates++
                            break
                        case "streamRecovery":
                        case "fwUpdate":
                        case "videoDeleted":
                        case "recordingDeleted":
                        case "applicationUpdatable":
                        case "streamRecovery":
                        case "resolutionLowered":
                        case "sensorDetectionSettingsChanged":
                        case "adminActivity":
                            break
                        default:
                            Logging( "Unhandled WSS Type for ${ Device }: ${ it }", 3 )
							break
                    }
                    break
                case "metadata":
                    it.each(){
                        Logging( "${ Device } Metadata = ${ it }", 4 )
                        switch( it.key ){
                            case "detectedThumbnails":
//                                        PostStateToChild( "${ Device }", "metadata-detectedThumbnails", it.value )
                                break
                            case "weather":
//                                    	PostStateToChild( "${ Device }", "metadata-weather", it.value )
                                 break
                                    // Ones to ignore
                            case "metadata": // Yes, it provides metadata in metadata and this drove me crazy for a bit...
                            case "clientPlatform":
                            case "ip":
                            case "userName":
                            case "deviceModelKey":
                            case "mountType":
                            case "sensorId":
                            case "sensorName":
                            case "type":
                                break
                            default:
                                Logging( "Unhandled WSS Metadata on ${ Device } ${ it.key } = ${ it.value }", 3 )
                                break
                        }
                    }
                    updates++
//                            PostStateToChild( "${ Device }", "metadata", it.value )
                    break
                case "lcdMessage":
//                            PostStateToChild( "${ Device }", "lcdMessage", it.value )
                    break
                case "createdAt":
                case "updatedAt":
                    ProcessState(it.key, it.value )
                    updates++
                    break
                case "motionDetectedAt":
 //                       	PostStateToChild( "${ Device }", "motionDetectedAt", ConvertEpochToDate( "${ it.value }" ) )
                    break
                case "functionButtonPressedAt":
//                        	PostStateToChild( "${ Device }", "functionButtonPressedAt", ConvertEpochToDate( "${ it.value }" ) )
                    break
                case "batteryStatus":
                    ProcessEvent( "battery", ( it.value.percentage / 100 ) )
                    updates++
                    break
                case "labels":
                    def Stringy = it.value as String
                    Logging( "WSS labels = ${ Stringy as String }", 4 )
                    def TempString = ""
                    def Detects = Stringy.count( "smartDetectType" )
                    def Split1
                   	def Count = 1
                    def Split2
                    if( Detects >= 1 ){
                        for( int i = 1; i <= Detects; i++ ){
                            Split1 = Stringy.split( "smartDetectType:" )[ 1 ]
                            TempString += Split1.split( "," )[ 0 ]
                            Split1 = Stringy.split( "," )[ 1 ]
                            if( i < Detects ){
                                TempString += ", "
                                }
                        }
                    } else {
                        TempString = "none"
                    }
                    Logging( "WSS smartDetectType Final = ${ TempString }", 4 )
                    ProcessEvent( "smartDetectType", TempString )
                    updates++
                    break
                case "systemInfo":
                    ProcessEvent( "temperature", ConvertTemperature( "C", it.value.cpu.temperature ), location.getTemperatureScale() )
                    ProcessEvent( "CPULoad", ( it.value.cpu.averageLoad / 100 ), "%" )
                    updates++
                    break
                case "ptz":
                    ProcessState( "ptz", "${ it.value }" )
                    updates++
                    break
                case "isOpened":
                    if( isOpened ){
                        ProcessEvent( "contact", "open" )
                    } else {
                        ProcessEvent( "contact", "closed" )
                    }
                    if( Data.actionPacket?.action?.toString() == "add" ){
                        if( isOpened ){
                            ProcessState( "LastWSSAction", "sensorOpened" )
                        } else {
                            ProcessState( "LastWSSAction", "sensorClosed" )
                        }
                    }
                    ProcessState( "LastWSSAction", "sensorOpened" )
                    updates++
                    break
                case "openStatusChangedAt":
//                        	PostStateToChild( "${ Device }", it, it.value )
                    break
						// Things to ignore
			    case "uptime":
				case "upSince":
				case "lastSeen":
				case "recordingSchedules":
                case "wifiConnectionState":
                case "partition":
                case "score":
                case "start":
                case "user":
                case "locked":
                case "isFavorite":
                case "modelKey":
                case "id":
                case "favoriteObjectIds":
                case "device":
                case "camera":
                case "nvrMac":
                case "uplinkDevice":
                case "end":
                case "thumbnailId":
                case "thumbnailFullfovId":
                case "deletionType":
                case "deletedAt":
                case "hqBytesPerDay":
                case "autoRetentionMs":
                case "phyRate":
                case "stats":
                case "wirelessConnectionState":
                case "bridgeCandidates":
                case "bridge":
                case "bluetoothConnectionState":
                case "wanPorts":
                case "portStatus":
                case "clients":
                case "ispSettings":
                case "hasRecordings":
                case "lqBytesPerDay":
                case "autoRetentionLqMs":
                case "videoReconfigurationInProgress":
				    break
			    default:
					Logging( "Unhandled WSS Update for ${ Device }: ${ it.key } = ${ it.value }", 3 )
					break
		    }
        }	
        if (updates > 0 ) {
            ProcessState( "LastWSSID", EventID )
        } 
    } else if( ( Data.actionPacket?.action?.toString() == "update" ) && ( ( Data.dataPacket == null ) || ( Data.dataPacket == "null" ) ) ){
	    if( LastActionID == EventID ){
	        switch( LastAction ){
				case "Dark":
				    ProcessEvent( "Dark", "true" )
					break
				case "motionDetected":
                    Logging( "LastAction motionDetected on ${ Device }", 4 )
				    ProcessEvent( "motion", "inactive" )
					break
				case "smartDetectType":
                    Logging( "smartDetectType = ${ it }", 4 )
                    def PreviousType = getChildDevice( "${ Device }" ).ReturnState( "smartDetectType" )
                    if( ( PreviousType != null ) && ( PreviousType != "null" ) ){
				        ProcessEvent( "smartDetectType", null )
                    }
					break
				case "Light":
					ProcessEvent( "${ Device }", "switch", "off" )
					break
				case "Recording Now":
					ProcessEvent( "${ Device }", "RecordingNow", "false" )
					break
                case "motion":
                    Logging( "LastAction motion on ${ Device }", 4 )
                    ProcessEvent( "${ Device }", "motion", "inactive" )
					break
                case "sensorMotion":
                    Logging( "LastAction sensorMotion on ${ Device }", 4 )
                    ProcessEvent( "${ Device }", "motion", "inactive" )
					break
                case "smartDetectZone":
                    ProcessEvent( "${ Device }", "smartDetectZone", "inactive" )
                    break
                case "access":
                    ProcessEvent( "${ Device }", "access", "inactive" )
                    break
                case "ring":
                    release( 1 )
				    break
                case "disconnect":
                    Logging( "${ Device } reconnected for WebSocket", 4 )
                    break
                case "sensorExtremeValues":
//                  PostStateToChild( "${ Device }", "SensorExtremeValues", null )
                    break
                case "smartAudioDetect":
                    ProcessEvent	( "${ Device }", "sound ", "not detected" )
                    break
                case "poorConnection":
//                        	PostStateToChild( "${ Device }", "DeviceConnection", "OK" )
                    break
                default:
                   Logging( "Unhandled LastAction ${ LastAction } for ${ Device }", 3 )
                   break
		    }
        }    
    }
/*    long duration = now() - startTime
    procTime += duration
    callCount++    
    
    def formattedDuration = formatDuration(duration)
    log.info "childPost() ChildPost call Elapse time ${formattedDuration}." */

}

def formatDuration(long milliseconds) {
    if (milliseconds < 1000) {
        return "${milliseconds} ms"
    }

    long seconds = milliseconds / 1000
    if (seconds < 60) {
        return "${seconds} s ${milliseconds % 1000} ms"
    }

    long minutes = seconds / 60
    if (minutes < 60) {
        return "${minutes} min ${seconds % 60} s ${milliseconds % 1000} ms"
    }

    long hours = minutes / 60
    return "${hours} h ${minutes % 60} min ${seconds % 60} s ${milliseconds % 1000} ms"
}

// Used to convert epoch values to text dates
def String ConvertEpochToDate( String Epoch ){
    def date
    if( ( Epoch != null ) && ( Epoch != "" ) && ( Epoch != "null" ) ){
        Long Temp = Epoch.toLong()
        if( Temp <= 9999999999 ){
            date = new Date( ( Temp * 1000 ) ).toString()
        } else {
            date = new Date( Temp ).toString()
        }
    } else {
        date = "Null value provided"
    }
    return date
}

// Return a state value
def ReturnState( Variable ){
    return state."${ Variable }"
}

// Tile method to produce HTML formatted string for dashboard use
private void UpdateTile( String val ){
    if( TileTemplate != null ){
        def TempString = ""
        Parsing = TileTemplate
        Parsing = Parsing.replaceAll( "\\[", "<" )
        Parsing = Parsing.replaceAll( "\\]", ">" )
        Count = Parsing.count( "@" )
        if( Count >= 1 ){
            def x = 1
            while( x <= Count ){
                TempName = Parsing.split( "@" )[ x ]
                switch( TempName ){
                    case "location.latitude":
                        Value = location.latitude
                        break
                    case "location.longitude":
                        Value = location.longitude
                        break
                    case "location.getTemperatureScale()":
                        Value = location.getTemperatureScale()
                        break
                    default:
                        Value = ReturnState( "${ TempName }" )
                        break
                }
                TempString = TempString + Parsing.split( "@" )[ ( x - 1 ) ] + Value
                x = ( x + 2 )
            }
            if( Parsing.split( "@" ).last() != Parsing.split( "@" )[ Count - 1 ] ){
                TempString = TempString + Parsing.split( "@" ).last()
            }
        } else if( Count == 1 ){
            TempName = Parsing.split( "@" )[ 1 ]
            switch( TempName ){
                case "location.latitude":
                    Value = location.latitude
                    break
                case "location.longitude":
                    Value = location.longitude
                    break
                case "location.getTemperatureScale()":
                    Value = location.getTemperatureScale()
                    break
                default:
                    Value = ReturnState( "${ TempName }" )
                    break
            }
            TempString = TempString + Parsing.split( "@" )[ 0 ] + Value
        } else {
            TempString = TileTemplate    
        }
        Logging( "Tile = ${ TempString }", 4 )
        sendEvent( name: "Tile", value: TempString )
    }
}


// Send event for device
def ProcessEvent( Variable, Value, Unit = null, Description = null ){
    sendEvent( name: Variable, value: Value, unit: Unit, descriptionText: Description )
    if( Unit != null ){
        if( Description != null ){
            Logging( "Event: ${ Variable } = ${ Value } Unit = ${ Unit } Description = ${ Description }", 4 )
        } else {
            Logging( "Event: ${ Variable } = ${ Value } Unit = ${ Unit }", 4 )
        }
    } else {
        if( Description != null ){
            Logging( "Event: ${ Variable } = ${ Value } Description = ${ Description }", 4 )
        } else {
            Logging( "Event: ${ Variable } = ${ Value }", 4 )
        }
    }
}

// Set a state variable to a value
def ProcessState( Variable, Value ){
    Logging( "State: ${ Variable } = ${ Value }", 4 )
    state."${ Variable }" = Value
    UpdateTile( "${ Value }" )
}

// Handles whether logging is enabled and thus what to put there.
def Logging( LogMessage, LogLevel ){
	// Add all messages as info logging
    if( ( LogLevel == 2 ) && ( LogType != "None" ) ){
        log.info( "${ device.displayName } - ${ LogMessage }" )
    } else if( ( LogLevel == 3 ) && ( ( LogType == "Debug" ) || ( LogType == "Trace" ) ) ){
        log.debug( "${ device.displayName } - ${ LogMessage }" )
    } else if( ( LogLevel == 4 ) && ( LogType == "Trace" ) ){
        log.trace( "${ device.displayName } - ${ LogMessage }" )
    } else if( LogLevel == 5 ){
        log.error( "${ device.displayName } - ${ LogMessage }" )
    }
}

// Checks drdsnell.com for the latest version of the driver
// Original inspiration from @cobra's version checking
def CheckForUpdate(){
    ProcessEvent( "DriverName", DRIVER )
    ProcessEvent( "DriverVersion", VERSION )
	httpGet( uri: "https://www.drdsnell.com/projects/hubitat/drivers/versions.json", contentType: "application/json" ){ resp ->
        switch( resp.status ){
            case 200:
                if( resp.data."${ DRIVER }" ){
                    CurrentVersion = VERSION.split( /\./ )
                    if( resp.data."${ DRIVER }".version == "REPLACED" ){
                       ProcessEvent( "DriverStatus", "Driver replaced, please use ${ resp.data."${ DRIVER }".file }" )
                    } else if( resp.data."${ DRIVER }".version == "REMOVED" ){
                       ProcessEvent( "DriverStatus", "Driver removed and no longer supported." )
                    } else {
                        SiteVersion = resp.data."${ DRIVER }".version.split( /\./ )
                        if( CurrentVersion == SiteVersion ){
                            Logging( "Driver version up to date", 2 )
				            ProcessEvent( "DriverStatus", "Up to date" )
                        } else if( ( CurrentVersion[ 0 ] as int ) > ( SiteVersion [ 0 ] as int ) ){
                            Logging( "Major development ${ CurrentVersion[ 0 ] }.${ CurrentVersion[ 1 ] }.${ CurrentVersion[ 2 ] } version", 4 )
				            ProcessEvent( "DriverStatus", "Major development ${ CurrentVersion[ 0 ] }.${ CurrentVersion[ 1 ] }.${ CurrentVersion[ 2 ] } version" )
                        } else if( ( CurrentVersion[ 1 ] as int ) > ( SiteVersion [ 1 ] as int ) ){
                            Logging( "Minor development ${ CurrentVersion[ 0 ] }.${ CurrentVersion[ 1 ] }.${ CurrentVersion[ 2 ] } version", 4 )
				            ProcessEvent( "DriverStatus", "Minor development ${ CurrentVersion[ 0 ] }.${ CurrentVersion[ 1 ] }.${ CurrentVersion[ 2 ] } version" )
                        } else if( ( CurrentVersion[ 2 ] as int ) > ( SiteVersion [ 2 ] as int ) ){
                            Logging( "Patch development ${ CurrentVersion[ 0 ] }.${ CurrentVersion[ 1 ] }.${ CurrentVersion[ 2 ] } version", 4 )
				            ProcessEvent( "DriverStatus", "Patch development ${ CurrentVersion[ 0 ] }.${ CurrentVersion[ 1 ] }.${ CurrentVersion[ 2 ] } version" )
                        } else if( ( SiteVersion[ 0 ] as int ) > ( CurrentVersion[ 0 ] as int ) ){
                            Logging( "New major release ${ SiteVersion[ 0 ] }.${ SiteVersion[ 1 ] }.${ SiteVersion[ 2 ] } available", 2 )
				            ProcessEvent( "DriverStatus", "New major release ${ SiteVersion[ 0 ] }.${ SiteVersion[ 1 ] }.${ SiteVersion[ 2 ] } available" )
                        } else if( ( SiteVersion[ 1 ] as int ) > ( CurrentVersion[ 1 ] as int ) ){
                            Logging( "New minor release ${ SiteVersion[ 0 ] }.${ SiteVersion[ 1 ] }.${ SiteVersion[ 2 ] } available", 2 )
				            ProcessEvent( "DriverStatus", "New minor release ${ SiteVersion[ 0 ] }.${ SiteVersion[ 1 ] }.${ SiteVersion[ 2 ] } available" )
                        } else if( ( SiteVersion[ 2 ] as int ) > ( CurrentVersion[ 2 ] as int ) ){
                            Logging( "New patch ${ SiteVersion[ 0 ] }.${ SiteVersion[ 1 ] }.${ SiteVersion[ 2 ] } available", 2 )
				            ProcessEvent( "DriverStatus", "New patch ${ SiteVersion[ 0 ] }.${ SiteVersion[ 1 ] }.${ SiteVersion[ 2 ] } available" )
                        }
                    }
                } else {
                    Logging( "${ DRIVER } is not published on drdsnell.com", 2 )
                    ProcessEvent( "DriverStatus", "${ DRIVER } is not published on drdsnell.com" )
                }
                break
            default:
                Logging( "Unable to check drdsnell.com for ${ DRIVER } driver updates.", 2 )
                break
        }
    }
}